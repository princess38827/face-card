export type Study = {
  id: string;
  title: string;
  price: number | null;
  focus: "face-card" | "face-tight";
};

export type Creator = {
  id: string;
  name: string;
  handle: string;
  city: string;
  role: string;
  age: number;
  price: number;
  portrait: string;
  live: boolean;
  viewers: number;
  bio: string;
  presence: string;
  since: string;
  tier: string;
  photos: number;
  followers: number;
  following: number;
  studies: Study[];
};

export type ChatLine = {
  name: string;
  text: string;
  time: string;
};

export type Note = {
  id: string;
  title: string;
  detail: string;
  when: string;
};

export const creators: Creator[] = [
  {
    id: "amelia",
    name: "Amelia V.",
    handle: "ameliav",
    city: "Paris",
    role: "Creative Director",
    age: 28,
    price: 12,
    portrait: "/portraits/amelia.jpg",
    live: true,
    viewers: 1248,
    bio: "Quiet light. Curated rooms. I make pictures for people who still look closely.",
    presence: "Your presence is a privilege.",
    since: "March 2024",
    tier: "Curated",
    photos: 128,
    followers: 24,
    following: 6,
    studies: [
      { id: "amelia-collar", title: "Collar and gold", price: null, focus: "face-card" },
      { id: "amelia-rue", title: "Rue des Archives", price: 12, focus: "face-tight" },
    ],
  },
  {
    id: "julian",
    name: "Julian Moreau",
    handle: "julianmoreau",
    city: "Côte d'Azur",
    role: "Architect",
    age: 31,
    price: 15,
    portrait: "/portraits/julian.jpg",
    live: false,
    viewers: 0,
    bio: "I build houses that know how to be quiet. The coast is the studio. Stone does the talking.",
    presence: "Stay for the long light.",
    since: "June 2023",
    tier: "Curated",
    photos: 64,
    followers: 22,
    following: 5,
    studies: [
      { id: "julian-stone", title: "Stone and noon", price: null, focus: "face-card" },
      { id: "julian-terrace", title: "The long terrace", price: 15, focus: "face-tight" },
    ],
  },
  {
    id: "sofia",
    name: "Sofia El-Masri",
    handle: "sofiaelmasri",
    city: "Marrakech",
    role: "Photographer",
    age: 27,
    price: 18,
    portrait: "/portraits/sofia.jpg",
    live: false,
    viewers: 0,
    bio: "I photograph faces before I photograph places. Dusk here is its own kind of gold.",
    presence: "Look once, then look properly.",
    since: "January 2025",
    tier: "Curated",
    photos: 86,
    followers: 31,
    following: 9,
    studies: [
      { id: "sofia-dusk", title: "Dusk on the medina", price: null, focus: "face-card" },
      { id: "sofia-face", title: "A face before the place", price: 12, focus: "face-tight" },
    ],
  },
  {
    id: "elena",
    name: "Elena Voss",
    handle: "elenavoss",
    city: "Milan",
    role: "Editor",
    age: 33,
    price: 9,
    portrait: "/portraits/elena.jpg",
    live: false,
    viewers: 0,
    bio: "I edit pages that still believe in paper. A good sentence should feel as inevitable as a collar.",
    presence: "Fewer words. Better ones.",
    since: "November 2024",
    tier: "Curated",
    photos: 41,
    followers: 19,
    following: 6,
    studies: [
      { id: "elena-collar", title: "The collar", price: null, focus: "face-tight" },
      { id: "elena-margin", title: "Margin notes", price: 9, focus: "face-card" },
    ],
  },
  {
    id: "lucien",
    name: "Lucien Hart",
    handle: "lucienhart",
    city: "London",
    role: "Atelier Director",
    age: 44,
    price: 19,
    portrait: "/portraits/lucien.jpg",
    live: false,
    viewers: 0,
    bio: "Twenty years of cloth, cut close and without noise. Elegance is mostly what you refuse.",
    presence: "Nothing extra. Nothing missing.",
    since: "August 2022",
    tier: "Founding",
    photos: 52,
    followers: 18,
    following: 4,
    studies: [
      { id: "lucien-cloth", title: "Charcoal cloth", price: null, focus: "face-card" },
      { id: "lucien-refuse", title: "What was refused", price: 20, focus: "face-tight" },
    ],
  },
  {
    id: "noor",
    name: "Noor Haddad",
    handle: "noorhaddad",
    city: "Beirut",
    role: "Stylist",
    age: 30,
    price: 14,
    portrait: "/portraits/noor.jpg",
    live: true,
    viewers: 486,
    bio: "I dress the hour after the invitation. Evening light, and the jewelry that outlasts it.",
    presence: "Stay. The light is finally right.",
    since: "April 2025",
    tier: "Curated",
    photos: 73,
    followers: 27,
    following: 7,
    studies: [
      { id: "noor-after", title: "After the invitation", price: null, focus: "face-card" },
      { id: "noor-gold", title: "Gold that stays", price: 14, focus: "face-tight" },
    ],
  },
];

export const ROOM_CHAT: Record<string, ChatLine[]> = {
  amelia: [
    { name: "Alexander", text: "Your presence lights up the room.", time: "10:24 PM" },
    { name: "Valentino", text: "Absolutely stunning, as always.", time: "10:25 PM" },
    { name: "Dominic", text: "The elegance is unmatched.", time: "10:25 PM" },
    { name: "Clara", text: "Simply unforgettable.", time: "10:26 PM" },
  ],
  noor: [
    { name: "Helena", text: "The gold at your throat catches the lamp.", time: "9:02 PM" },
    { name: "Marcus", text: "Quiet, and completely certain.", time: "9:04 PM" },
    { name: "Adele", text: "This is the standard.", time: "9:06 PM" },
  ],
};

export const SEED_NOTES: Note[] = [
  {
    id: "seed-live",
    title: "Amelia V. is live",
    detail: "Paris · a quiet room, open to the house.",
    when: "This hour",
  },
  {
    id: "seed-noor",
    title: "Noor Haddad is live",
    detail: "Beirut · evening light, intentionally framed.",
    when: "This hour",
  },
  {
    id: "seed-sofia",
    title: "A new study from Sofia El-Masri",
    detail: "Dusk on the medina. Soft light, strong face.",
    when: "Last night",
  },
  {
    id: "seed-julian",
    title: "Julian Moreau published a study",
    detail: "The long terrace. Côte d'Azur, late light.",
    when: "Yesterday",
  },
];

export function getCreator(id: string) {
  return creators.find((creator) => creator.id === id);
}

export function money(amount: number) {
  return Number.isInteger(amount) ? `$${amount}` : `$${amount.toFixed(2)}`;
}

export function kept(amount: number) {
  return Math.round(amount * 0.85 * 100) / 100;
}

export function houseFee(amount: number) {
  return Math.round(amount * 0.15 * 100) / 100;
}
