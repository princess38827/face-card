import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { creators, money, type ChatLine, type Note } from "@/lib/creators";

export type Application = {
  name: string;
  bio: string;
  price: number;
  priceSet: boolean;
  guidelines: boolean;
  ofAge: boolean;
  verified: boolean;
  portraitReady: boolean;
  scheduled: string | null;
  approved: boolean;
};

export type Tip = {
  id: string;
  creatorId: string;
  label: string;
  amount: number;
  when: string;
};

type House = {
  hydrated: boolean;
  saved: string[];
  joined: Record<string, number>;
  unlocked: string[];
  privateRequests: string[];
  notes: Note[];
  messages: Record<string, ChatLine[]>;
  tips: Tip[];
  application: Application | null;
  toggleSave: (id: string) => void;
  join: (id: string, price: number) => void;
  leave: (id: string) => void;
  unlock: (id: string, creatorId: string, title: string, amount: number) => void;
  requestPrivate: (id: string) => void;
  sendTip: (creatorId: string, label: string, amount: number) => void;
  sendMessage: (roomId: string, line: ChatLine) => void;
  patchApplication: (partial: Partial<Application>) => void;
  approve: () => void;
};

const blank = (): Application => ({
  name: "",
  bio: "",
  price: 15,
  priceSet: false,
  guidelines: false,
  ofAge: false,
  verified: false,
  portraitReady: false,
  scheduled: null,
  approved: false,
});

function note(title: string, detail: string): Note {
  return { id: crypto.randomUUID(), title, detail, when: "Just now" };
}

function creatorName(id: string) {
  return creators.find((creator) => creator.id === id)?.name ?? "the house";
}

export const useHouse = create<House>()(
  persist(
    (set, get) => ({
      hydrated: false,
      saved: [],
      joined: {},
      unlocked: [],
      privateRequests: [],
      notes: [],
      messages: {},
      tips: [],
      application: null,
      toggleSave: (id) => {
        const has = get().saved.includes(id);
        const name = creatorName(id);
        set({
          saved: has ? get().saved.filter((item) => item !== id) : [...get().saved, id],
          notes: has
            ? get().notes
            : [note(`Kept ${name}`, "Added to your favorites."), ...get().notes].slice(0, 30),
        });
      },
      join: (id, price) => {
        if (get().joined[id]) return;
        set({
          joined: { ...get().joined, [id]: price },
          notes: [
            note(`You joined ${creatorName(id)}`, `${money(price)} / month · they keep 85%.`),
            ...get().notes,
          ].slice(0, 30),
        });
      },
      leave: (id) => {
        const joined = { ...get().joined };
        delete joined[id];
        set({ joined });
      },
      unlock: (id, creatorId, title, amount) => {
        if (get().unlocked.includes(id)) return;
        set({
          unlocked: [...get().unlocked, id],
          notes: [
            note(`Unlocked ${title}`, `${creatorName(creatorId)} keeps ${money(Math.round(amount * 0.85 * 100) / 100)}.`),
            ...get().notes,
          ].slice(0, 30),
        });
      },
      requestPrivate: (id) => {
        if (get().privateRequests.includes(id)) return;
        set({
          privateRequests: [...get().privateRequests, id],
          notes: [
            note(`Private room requested`, `With ${creatorName(id)}. Arranged 1:1, never rushed.`),
            ...get().notes,
          ].slice(0, 30),
        });
      },
      sendTip: (creatorId, label, amount) => {
        set({
          tips: [
            { id: crypto.randomUUID(), creatorId, label, amount, when: "Just now" },
            ...get().tips,
          ].slice(0, 30),
          notes: [
            note(`${label} for ${creatorName(creatorId)}`, `${money(amount)} · they keep 85%.`),
            ...get().notes,
          ].slice(0, 30),
        });
      },
      sendMessage: (roomId, line) => {
        const prev = get().messages[roomId] ?? [];
        set({ messages: { ...get().messages, [roomId]: [...prev, line].slice(-40) } });
      },
      patchApplication: (partial) => {
        set({ application: { ...(get().application ?? blank()), ...partial } });
      },
      approve: () => {
        const current = get().application ?? blank();
        set({
          application: { ...current, approved: true },
          notes: [
            note("Your face-card is active", "The house approved your application."),
            ...get().notes,
          ].slice(0, 30),
        });
      },
    }),
    {
      name: "face-card-house",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (state) => ({
        saved: state.saved,
        joined: state.joined,
        unlocked: state.unlocked,
        privateRequests: state.privateRequests,
        notes: state.notes,
        messages: state.messages,
        tips: state.tips,
        application: state.application,
      }),
    },
  ),
);
