import { Link } from "@tanstack/react-router";

export function NotFound() {
  return (
    <main className="flex min-h-full flex-col items-center justify-center gap-4 px-8 text-center">
      <p className="font-display text-4xl text-gold">Not in the house</p>
      <p className="text-muted">This card was never issued.</p>
      <Link to="/" className="btn-gold mt-2 rounded-full px-6 py-3 font-display text-xl">
        Return home
      </Link>
    </main>
  );
}
