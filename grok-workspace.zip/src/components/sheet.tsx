import type { ReactNode } from "react";
import { X } from "lucide-react";

export function Sheet({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-bg/70" role="dialog" aria-modal="true" aria-label={title}>
      <button type="button" className="absolute inset-0" aria-label="Close" onClick={onClose} />
      <div className="glass rim relative z-10 max-h-[85dvh] w-full max-w-md overflow-y-auto rounded-t-card px-5 pt-5 pb-8">
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="font-display text-3xl text-gold">{title}</h2>
          <button type="button" onClick={onClose} aria-label="Close" className="grid size-11 place-items-center text-muted">
            <X className="size-5" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Rule() {
  return (
    <div className="flex items-center gap-3 text-gold" aria-hidden="true">
      <span className="h-px flex-1 bg-gold/30" />
      <svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor">
        <path d="M5 0.5 9.5 5 5 9.5 0.5 5Z" />
      </svg>
      <span className="h-px flex-1 bg-gold/30" />
    </div>
  );
}
