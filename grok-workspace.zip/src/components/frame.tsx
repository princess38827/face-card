import { useEffect, useState, type ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { Heart, Plus, Search, SquareStack, UserRound } from "lucide-react";
import { creators } from "@/lib/creators";
import { useHouse } from "@/lib/store";
import { Sheet } from "@/components/sheet";

export function AppFrame({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (state) => state.location.pathname });
  const navigate = useNavigate();
  const [splash, setSplash] = useState(true);
  const [compose, setCompose] = useState(false);
  const hydrated = useHouse((state) => state.hydrated);
  const application = useHouse((state) => state.application);
  const bare = path.startsWith("/live") || path.startsWith("/profile") || path.startsWith("/apply");
  const liveNow = creators.filter((creator) => creator.live);

  useEffect(() => {
    void Promise.resolve(useHouse.persist.rehydrate()).finally(() => {
      useHouse.setState({ hydrated: true });
    });
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => setSplash(false), 1600);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    setCompose(false);
  }, [path]);

  return (
    <div className="flex h-dvh justify-center overflow-hidden bg-bg text-ivory">
      <aside className="hidden h-dvh min-w-0 flex-1 flex-col justify-center px-10 xl:flex">
        <div className="ml-auto max-w-xs">
          <p className="text-xs tracking-widest text-gold">QUIET LUXURY</p>
          <p className="wordmark mt-3 text-5xl text-ivory">Face-card</p>
          <p className="mt-2 font-display text-xl text-warm italic">Because the face-card never declines.</p>
          <p className="mt-6 text-sm text-muted">
            A curated house for exceptional presence. Founding members only.
          </p>
          <p className="mt-8 text-sm text-ivory">Creators keep 85%.</p>
          <p className="text-sm text-muted">The house keeps 15%.</p>
        </div>
      </aside>

      <div className="relative flex h-dvh w-full max-w-md shrink-0 flex-col border-x border-gold/15">
        {splash && path === "/" ? (
          <button
            type="button"
            className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-bg px-8"
            onClick={() => setSplash(false)}
            aria-label="Enter Face-card"
          >
            <img src="/media/mark.png" alt="" className="mark-glow w-52" />
            <p className="mt-6 text-center font-display text-lg text-warm italic">
              Because the face-card never declines.
            </p>
            <div className="mt-8 h-0.5 w-40 overflow-hidden bg-gold/15">
              <div className="splash-bar" />
            </div>
          </button>
        ) : null}

        <div className="pane min-h-0 flex-1 overflow-y-auto">{children}</div>

        {bare ? null : (
          <nav className="nav-pad relative grid shrink-0 grid-cols-5 items-end border-t border-gold/20 bg-bg/95 px-1 pt-3 backdrop-blur-xl">
            <NavItem to="/" label="Home" icon={<SquareStack className="size-5" strokeWidth={1.5} />} exact />
            <NavItem to="/discover" label="Discover" icon={<Search className="size-5" strokeWidth={1.5} />} />
            <div className="relative h-12">
              <button
                type="button"
                aria-label="Create"
                onClick={() => setCompose(true)}
                className="btn-gold absolute left-1/2 top-0 grid size-14 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full"
              >
                <Plus className="size-6" strokeWidth={1.75} />
              </button>
            </div>
            <NavItem to="/activity" label="Activity" icon={<Heart className="size-5" strokeWidth={1.5} />} />
            <NavItem to="/me" label="Profile" icon={<UserRound className="size-5" strokeWidth={1.5} />} />
          </nav>
        )}

        {compose ? (
          <Sheet title={application?.approved ? "Your card" : "The house"} onClose={() => setCompose(false)}>
            {!hydrated ? (
              <p className="text-muted">One moment.</p>
            ) : application?.approved ? (
              <div className="space-y-4">
                <p className="font-display text-xl italic text-ivory">
                  Your face-card is active. The room can be yours.
                </p>
                <button
                  type="button"
                  className="btn-gold h-12 w-full rounded-full font-display text-2xl"
                  onClick={() => {
                    setCompose(false);
                    void navigate({ to: "/live/$id", params: { id: "studio" } });
                  }}
                >
                  Go live
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-sm text-ivory">
                  A face-card is extended, not claimed. If your presence already meets the standard, request consideration.
                </p>
                <button
                  type="button"
                  className="btn-gold h-12 w-full rounded-full font-display text-2xl"
                  onClick={() => {
                    setCompose(false);
                    void navigate({ to: "/apply" });
                  }}
                >
                  Request a card
                </button>
              </div>
            )}
          </Sheet>
        ) : null}
      </div>

      <aside className="hidden h-dvh min-w-0 flex-1 flex-col justify-end px-10 pb-16 xl:flex">
        <div className="max-w-xs">
          <p className="text-xs tracking-widest text-gold">LIVE NOW</p>
          <ul className="mt-4 space-y-3">
            {liveNow.map((creator) => (
              <li key={creator.id}>
                <Link to="/live/$id" params={{ id: creator.id }} className="group block">
                  <span className="font-display text-2xl text-ivory group-hover:text-gold">{creator.name}</span>
                  <span className="mt-0.5 block text-sm text-muted">
                    {creator.city} · {creator.viewers.toLocaleString()} watching
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </aside>
    </div>
  );
}

function NavItem({
  to,
  label,
  icon,
  exact,
}: {
  to: "/" | "/discover" | "/activity" | "/me";
  label: string;
  icon: ReactNode;
  exact?: boolean;
}) {
  const path = useRouterState({ select: (state) => state.location.pathname });
  const on = exact ? path === to : path === to || path.startsWith(`${to}/`);
  return (
    <Link
      to={to}
      className={`flex min-h-11 flex-col items-center justify-end gap-1 pb-1 ${on ? "text-gold" : "text-muted"}`}
    >
      {icon}
      <span className="text-xs">{label}</span>
    </Link>
  );
}
