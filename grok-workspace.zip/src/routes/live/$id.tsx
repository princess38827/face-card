import { useEffect, useRef, useState, type FormEvent } from "react";
import { createFileRoute, useNavigate, useRouter } from "@tanstack/react-router";
import { Bookmark, ChevronLeft, Crown, Ellipsis, Eye, Flag, Gem, Gift, Lock, Send, Share } from "lucide-react";
import { getCreator, houseFee, kept, money, ROOM_CHAT, type ChatLine, type Creator } from "@/lib/creators";
import { useHouse } from "@/lib/store";
import { NotFound } from "@/components/not-found";
import { Rule, Sheet } from "@/components/sheet";

export const Route = createFileRoute("/live/$id")({ component: LivePage });

const TIPS = [
  { label: "Rose", amount: 10 },
  { label: "Champagne", amount: 25 },
  { label: "Atelier", amount: 50 },
  { label: "Toast", amount: 100 },
];

function LivePage() {
  const { id } = Route.useParams();
  const hydrated = useHouse((state) => state.hydrated);
  const application = useHouse((state) => state.application);
  const navigate = useNavigate();
  const creator = getCreator(id);

  useEffect(() => {
    if (!hydrated) return;
    if (id === "studio" && !application?.approved) {
      void navigate({ to: "/apply" });
    }
  }, [hydrated, id, application?.approved, navigate]);

  if (id === "studio") {
    if (!hydrated || !application?.approved) {
      return (
        <main className="grid min-h-full place-items-center">
          <p className="font-display text-2xl text-gold">Opening the room…</p>
        </main>
      );
    }
    return (
      <Room
        host
        creator={{
          id: "studio",
          name: application.name || "Your card",
          handle: "you",
          city: "The house",
          role: "Founding",
          age: 0,
          price: application.price,
          portrait: "",
          live: true,
          viewers: 18,
          bio: application.bio,
          presence: "The light is yours.",
          since: "Tonight",
          tier: "Curated",
          photos: 0,
          followers: 0,
          following: 0,
          studies: [],
        }}
      />
    );
  }

  if (!creator) return <NotFound />;
  return <Room creator={creator} />;
}

function Room({ creator, host = false }: { creator: Creator; host?: boolean }) {
  const router = useRouter();
  const navigate = useNavigate();
  const saved = useHouse((state) => state.saved.includes(creator.id));
  const toggleSave = useHouse((state) => state.toggleSave);
  const extra = useHouse((state) => state.messages[creator.id] ?? []);
  const sendMessage = useHouse((state) => state.sendMessage);
  const sendTip = useHouse((state) => state.sendTip);
  const requestPrivate = useHouse((state) => state.requestPrivate);
  const requested = useHouse((state) => state.privateRequests.includes(creator.id));
  const unlocked = useHouse((state) => state.unlocked);
  const unlock = useHouse((state) => state.unlock);
  const [draft, setDraft] = useState("");
  const [watching, setWatching] = useState(creator.viewers);
  const [tipOpen, setTipOpen] = useState(false);
  const [chosen, setChosen] = useState<(typeof TIPS)[number] | null>(null);
  const [privateOpen, setPrivateOpen] = useState(false);
  const [exclusiveOpen, setExclusiveOpen] = useState(false);
  const [report, setReport] = useState(false);
  const [menu, setMenu] = useState(false);
  const [ribbon, setRibbon] = useState("");
  const endRef = useRef<HTMLDivElement>(null);
  const greeted = useRef(false);
  const lines = [...(ROOM_CHAT[creator.id] ?? []), ...extra];
  const locked = creator.studies.filter((study) => study.price != null && !unlocked.includes(study.id));

  useEffect(() => {
    const timer = window.setInterval(() => setWatching((value) => value + 1), 9000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" });
  }, [lines.length]);

  useEffect(() => {
    if (!host || greeted.current) return;
    const existing = useHouse.getState().messages.studio ?? [];
    if (existing.some((line) => line.name === "Clara")) {
      greeted.current = true;
      return;
    }
    greeted.current = true;
    const timer = window.setTimeout(() => {
      sendMessage("studio", {
        name: "Clara",
        text: "The light on you is enough.",
        time: clock(),
      });
      setRibbon("Clara is in the room");
    }, 2400);
    return () => window.clearTimeout(timer);
  }, [host, sendMessage]);

  function publish(line: ChatLine) {
    sendMessage(creator.id, line);
  }

  function onSend(event: FormEvent) {
    event.preventDefault();
    const text = draft.trim();
    if (!text) return;
    publish({ name: host ? creator.name : "You", text, time: clock() });
    setDraft("");
  }

  return (
    <main className="relative min-h-full">
      {creator.portrait ? (
        <img src={creator.portrait} alt="" className="live-drift face absolute inset-0 h-full w-full" />
      ) : (
        <div className="stage-glow absolute inset-0" />
      )}
      <div className="absolute inset-0 bg-linear-to-b from-bg/70 via-bg/15 to-bg/85" />

      <div className="relative z-10 flex min-h-full flex-col px-4 pt-4 pb-5">
        <header className="flex items-center gap-3">
          <button
            type="button"
            aria-label="Back"
            onClick={() => router.history.back()}
            className="grid size-11 place-items-center text-ivory"
          >
            <ChevronLeft className="size-5" />
          </button>
          {creator.portrait ? (
            <img src={creator.portrait} alt="" className="face size-10 rounded-full object-cover" />
          ) : (
            <img src="/media/mark.png" alt="" className="size-10 rounded-xl object-cover" />
          )}
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium">Face-card Live Room</p>
            <p className="text-xs tracking-wide text-muted">Exclusive · Intimate · Real</p>
          </div>
          <button type="button" aria-label="Share" className="grid size-11 place-items-center text-gold" onClick={() => setRibbon("Kept for the house")}>
            <Share className="size-4" />
          </button>
          <button
            type="button"
            aria-label={saved ? "Remove bookmark" : "Bookmark"}
            aria-pressed={saved}
            className="grid size-11 place-items-center text-gold"
            onClick={() => {
              if (creator.id !== "studio") toggleSave(creator.id);
            }}
          >
            <Bookmark className={saved ? "size-4 fill-gold" : "size-4"} />
          </button>
          <button type="button" aria-label="More" className="grid size-11 place-items-center text-gold" onClick={() => setMenu((value) => !value)}>
            <Ellipsis className="size-4" />
          </button>
        </header>
        {menu ? (
          <button
            type="button"
            onClick={() => {
              setMenu(false);
              setReport(true);
            }}
            className="glass mt-2 ml-auto flex items-center gap-2 rounded-full px-4 py-2 text-sm"
          >
            <Flag className="size-4 text-gold" />
            Report
          </button>
        ) : null}

        <div className="mt-4 flex items-start justify-between">
          <span className="inline-flex items-center gap-2 rounded-full border border-gold/50 px-3 py-1 text-xs tracking-widest text-gold">
            <span className="live-pip-gold" />
            LIVE
          </span>
          <div className="text-right">
            <p className="flex items-center justify-end gap-1 text-sm tabular-nums">
              <Eye className="size-3.5 text-ivory" />
              {watching.toLocaleString()}
            </p>
            <p className="text-xs text-muted">watching</p>
          </div>
        </div>

        <div className="flex-1" />

        <h1 className="font-display text-5xl text-ivory">{creator.name}</h1>
        <p className="mt-1 font-display text-lg text-gold italic">{creator.presence}</p>

        <section className="glass mt-4 rounded-card px-4 py-4">
          <Rule />
          <ul className="mt-3 max-h-40 space-y-3 overflow-y-auto">
            {lines.map((line, index) => (
              <li key={`${line.name}-${line.time}-${index}`} className="flex gap-3">
                <span className="grid size-8 shrink-0 place-items-center rounded-full border border-gold/40 font-display text-gold">
                  {line.name.slice(0, 1)}
                </span>
                <div className="min-w-0">
                  <p className="text-sm">
                    <span className="text-ivory">{line.name}</span>{" "}
                    <span className="text-muted">{line.time}</span>
                  </p>
                  <p className="text-sm text-ivory/90">{line.text}</p>
                </div>
              </li>
            ))}
            <div ref={endRef} />
          </ul>

          <form onSubmit={onSend} className="mt-3 flex items-center rounded-xl border border-gold/30 px-3">
            <input
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              placeholder="Send a private message..."
              aria-label="Send a private message"
              className="h-11 min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-muted"
            />
            <button type="submit" aria-label="Send" className="grid size-10 place-items-center text-gold" disabled={!draft.trim()}>
              <Send className="size-4" />
            </button>
          </form>

          {host ? (
            <button
              type="button"
              className="btn-line mt-3 h-12 w-full rounded-2xl text-sm tracking-widest"
              onClick={() => void navigate({ to: "/" })}
            >
              END THE ROOM
            </button>
          ) : (
            <div className="mt-3 grid grid-cols-3 gap-2">
              <button type="button" className="btn-line flex flex-col items-center rounded-2xl px-1 py-2.5" onClick={() => setTipOpen(true)}>
                <Gift className="size-4 text-gold" />
                <span className="mt-1 text-xs tracking-wide text-gold">SEND TIP</span>
                <span className="text-xs text-muted">Gratuity</span>
              </button>
              <button type="button" className="btn-line flex flex-col items-center rounded-2xl px-1 py-2.5" onClick={() => setPrivateOpen(true)}>
                <Gem className="size-4 text-gold" />
                <span className="mt-1 text-xs tracking-wide text-gold">PRIVATE</span>
                <span className="text-xs text-muted">1:1</span>
              </button>
              <button type="button" className="btn-line flex flex-col items-center rounded-2xl px-1 py-2.5" onClick={() => setExclusiveOpen(true)}>
                <Crown className="size-4 text-gold" />
                <span className="mt-1 text-xs tracking-wide text-gold">EXCLUSIVE</span>
                <span className="text-xs text-muted">Unlock</span>
              </button>
            </div>
          )}

          <p className="mt-3 flex items-center justify-center gap-2 text-xs text-muted">
            <Lock className="size-3" />
            Private · Secure · Discreet
          </p>
          {ribbon ? <p className="mt-2 text-center text-xs text-gold">{ribbon}</p> : null}
        </section>
      </div>

      {tipOpen ? (
        <Sheet title="Send a tip" onClose={() => { setTipOpen(false); setChosen(null); }}>
          <div className="grid grid-cols-2 gap-2">
            {TIPS.map((tip) => (
              <button
                key={tip.label}
                type="button"
                onClick={() => setChosen(tip)}
                className={`h-16 rounded-card border ${chosen?.label === tip.label ? "border-gold bg-gold text-bg" : "btn-line"}`}
              >
                <span className="block font-display text-xl">{tip.label}</span>
                <span className="text-xs">{money(tip.amount)}</span>
              </button>
            ))}
          </div>
          {chosen ? (
            <p className="mt-4 text-sm text-muted">
              {creator.name} keeps {money(kept(chosen.amount))}. The house keeps {money(houseFee(chosen.amount))}.
            </p>
          ) : null}
          <button
            type="button"
            disabled={!chosen}
            className="btn-gold mt-4 h-12 w-full rounded-full font-display text-2xl disabled:opacity-40"
            onClick={() => {
              if (!chosen) return;
              sendTip(creator.id, chosen.label, chosen.amount);
              publish({
                name: "You",
                text: `Raised a glass — ${chosen.label}.`,
                time: clock(),
              });
              setRibbon(`${chosen.label} received`);
              setChosen(null);
              setTipOpen(false);
            }}
          >
            Send
          </button>
        </Sheet>
      ) : null}

      {privateOpen ? (
        <Sheet title="Private room" onClose={() => setPrivateOpen(false)}>
          <p className="text-sm text-ivory">
            A 1:1 with {creator.name}, arranged rather than demanded. From $80. They keep 85%.
          </p>
          <button
            type="button"
            disabled={requested}
            className="btn-gold mt-5 h-12 w-full rounded-full font-display text-2xl disabled:opacity-60"
            onClick={() => {
              requestPrivate(creator.id);
              setRibbon("Your request is with them");
              setPrivateOpen(false);
            }}
          >
            {requested ? "Requested" : "Request the room"}
          </button>
        </Sheet>
      ) : null}

      {exclusiveOpen ? (
        <Sheet title="Exclusive" onClose={() => setExclusiveOpen(false)}>
          {locked.length === 0 ? (
            <p className="text-sm text-muted">Nothing is held back. The open studies are on their card.</p>
          ) : (
            <ul className="space-y-2">
              {locked.map((study) => (
                <li key={study.id} className="rim flex items-center justify-between rounded-card px-4 py-3">
                  <span className="font-display text-xl">{study.title}</span>
                  <button
                    type="button"
                    className="text-sm text-gold"
                    onClick={() => {
                      unlock(study.id, creator.id, study.title, study.price ?? 0);
                      setRibbon(`${study.title} is yours`);
                      setExclusiveOpen(false);
                    }}
                  >
                    {money(study.price ?? 0)}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Sheet>
      ) : null}

      {report ? (
        <Sheet title="For the house" onClose={() => setReport(false)}>
          <p className="text-sm text-ivory">Noted. The house will review this room against the standard.</p>
        </Sheet>
      ) : null}
    </main>
  );
}

function clock() {
  return new Intl.DateTimeFormat("en-US", { hour: "numeric", minute: "2-digit" }).format(new Date());
}
