import { createFileRoute, Link } from "@tanstack/react-router";
import { SEED_NOTES } from "@/lib/creators";
import { useHouse } from "@/lib/store";

export const Route = createFileRoute("/activity")({ component: Activity });

function Activity() {
  const notes = useHouse((state) => state.notes);
  const items = [...notes, ...SEED_NOTES];

  return (
    <main className="px-4 pt-6 pb-8">
      <h1 className="font-display text-4xl text-gold">Activity</h1>
      <p className="mt-1 text-sm text-muted">The house, quietly.</p>
      <ul className="mt-5 space-y-3">
        {items.map((item) => (
          <li key={item.id} className="rim rounded-card bg-surface/70 px-4 py-4">
            <p className="font-display text-2xl text-ivory">{item.title}</p>
            <p className="mt-1 text-sm text-muted">{item.detail}</p>
            <p className="mt-2 text-xs tracking-widest text-gold">{item.when}</p>
          </li>
        ))}
      </ul>
      <p className="mt-8 text-center text-sm text-muted">
        <Link to="/discover" className="text-gold">
          Find someone live
        </Link>
      </p>
    </main>
  );
}
