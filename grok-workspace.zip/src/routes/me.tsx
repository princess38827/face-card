import { createFileRoute, Link } from "@tanstack/react-router";
import { creators, money } from "@/lib/creators";
import { useHouse } from "@/lib/store";

export const Route = createFileRoute("/me")({ component: Me });

function Me() {
  const saved = useHouse((state) => state.saved);
  const joined = useHouse((state) => state.joined);
  const tips = useHouse((state) => state.tips);
  const application = useHouse((state) => state.application);
  const kept = creators.filter((creator) => saved.includes(creator.id));
  const circles = creators.filter((creator) => joined[creator.id]);
  const approved = Boolean(application?.approved);

  return (
    <main className="px-4 pt-6 pb-10">
      <h1 className="font-display text-4xl text-gold">Your card</h1>
      <section className="rim mt-5 rounded-card bg-surface/80 p-5">
        <div className="flex items-center gap-4">
          <img src="/media/mark.png" alt="" className="size-16 rounded-2xl object-cover" />
          <div>
            <p className="font-display text-2xl text-ivory">
              {approved ? application?.name || "Your card" : circles.length ? "Member" : "Guest of the house"}
            </p>
            <p className="text-sm text-muted">
              {approved ? "Face-card active" : "Founding circle · by invitation of taste"}
            </p>
          </div>
        </div>
        {approved && application ? (
          <p className="mt-4 font-display text-lg text-warm italic">{application.bio}</p>
        ) : (
          <p className="mt-4 text-sm text-muted">
            Because the face-card never declines. Keep the faces that stay with you.
          </p>
        )}
      </section>

      <section className="mt-8">
        <h2 className="text-xs tracking-widest text-gold">FAVORITES</h2>
        {kept.length === 0 ? (
          <p className="mt-3 text-sm text-muted">Faces you keep will rest here.</p>
        ) : (
          <ul className="mt-3 flex gap-3 overflow-x-auto">
            {kept.map((creator) => (
              <li key={creator.id}>
                <Link to="/profile/$id" params={{ id: creator.id }} className="block w-20 text-center">
                  <img src={creator.portrait} alt="" className="face size-20 rounded-full object-cover" />
                  <span className="mt-1 block truncate text-xs text-muted">{creator.name}</span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="mt-8">
        <h2 className="text-xs tracking-widest text-gold">CIRCLES</h2>
        {circles.length === 0 ? (
          <p className="mt-3 text-sm text-muted">You have not joined a circle yet.</p>
        ) : (
          <ul className="mt-3 space-y-2">
            {circles.map((creator) => (
              <li key={creator.id}>
                <Link
                  to="/profile/$id"
                  params={{ id: creator.id }}
                  className="rim flex items-center justify-between rounded-card px-4 py-3"
                >
                  <span className="font-display text-xl">{creator.name}</span>
                  <span className="text-sm text-gold">{money(joined[creator.id] ?? creator.price)}/mo</span>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>

      {tips.length > 0 ? (
        <section className="mt-8">
          <h2 className="text-xs tracking-widest text-gold">GRATUITIES</h2>
          <ul className="mt-3 space-y-2">
            {tips.map((tip) => {
              const name = creators.find((creator) => creator.id === tip.creatorId)?.name ?? "the house";
              return (
                <li key={tip.id} className="text-sm text-muted">
                  {tip.label} for {name} · {money(tip.amount)}
                </li>
              );
            })}
          </ul>
        </section>
      ) : null}

      <section className="rim mt-8 rounded-card p-5">
        <p className="font-display text-2xl text-ivory">85 / 15</p>
        <p className="mt-2 text-sm text-muted">
          Creators keep 85% of every subscription, tip, and study. The house retains 15% — more generous than the rooms it replaces.
        </p>
        {approved ? (
          <Link
            to="/live/$id"
            params={{ id: "studio" }}
            className="btn-gold mt-5 flex h-12 items-center justify-center rounded-full font-display text-2xl"
          >
            Go live
          </Link>
        ) : (
          <Link
            to="/apply"
            className="btn-gold mt-5 flex h-12 items-center justify-center rounded-full font-display text-2xl"
          >
            {application ? "Continue your request" : "Request a face-card"}
          </Link>
        )}
      </section>
    </main>
  );
}
