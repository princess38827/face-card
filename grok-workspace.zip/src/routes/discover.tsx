import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { creators } from "@/lib/creators";
import { useHouse } from "@/lib/store";

export const Route = createFileRoute("/discover")({ component: Discover });

const FILTERS = ["All", "Live", "Saved", "Paris", "Côte d'Azur", "Marrakech", "Milan", "London", "Beirut"];

function Discover() {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("All");
  const saved = useHouse((state) => state.saved);

  const shown = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return creators.filter((creator) => {
      const matches =
        !needle ||
        [creator.name, creator.city, creator.role, creator.handle].some((value) =>
          value.toLowerCase().includes(needle),
        );
      if (!matches) return false;
      if (filter === "Live") return creator.live;
      if (filter === "Saved") return saved.includes(creator.id);
      if (filter !== "All") return creator.city === filter;
      return true;
    });
  }, [query, filter, saved]);

  return (
    <main className="px-4 pt-6 pb-8">
      <h1 className="font-display text-4xl text-gold">Discover</h1>
      <p className="mt-1 text-sm text-muted">The house, by name and by city.</p>
      <label className="rim mt-5 flex h-12 items-center gap-3 rounded-full px-4">
        <Search className="size-4 text-gold" />
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search the house"
          className="w-full bg-transparent text-sm outline-none placeholder:text-muted"
          aria-label="Search the house"
        />
      </label>
      <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
        {FILTERS.map((item) => {
          const on = item === filter;
          return (
            <button
              key={item}
              type="button"
              onClick={() => setFilter(item)}
              className={`h-9 shrink-0 rounded-full border px-4 text-sm ${on ? "border-gold bg-gold text-bg" : "border-gold/30 text-muted"}`}
            >
              {item}
            </button>
          );
        })}
      </div>
      {shown.length === 0 ? (
        <p className="mt-10 text-center font-display text-2xl text-muted">No one in the house by that name.</p>
      ) : (
        <ul className="mt-4 grid grid-cols-2 gap-3">
          {shown.map((creator) => (
            <li key={creator.id}>
              <Link
                to="/profile/$id"
                params={{ id: creator.id }}
                className="rim block overflow-hidden rounded-card"
              >
                <div className="relative aspect-3/4">
                  <img src={creator.portrait} alt="" className="face absolute inset-0 h-full w-full" />
                  <div className="absolute inset-0 bg-linear-to-t from-bg via-transparent to-transparent" />
                  {creator.live ? (
                    <span className="absolute top-2 right-2 flex items-center gap-1.5 rounded-full bg-bg/70 px-2 py-1 text-xs tracking-widest text-gold">
                      <span className="live-pip" />
                      LIVE
                    </span>
                  ) : null}
                  <div className="absolute inset-x-0 bottom-0 p-3">
                    <p className="font-display text-xl leading-none text-ivory">{creator.name}</p>
                    <p className="mt-1 text-xs text-muted">{creator.city}</p>
                  </div>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
