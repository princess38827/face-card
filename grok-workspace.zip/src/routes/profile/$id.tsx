import { useState } from "react";
import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { BadgeCheck, ChevronLeft, Ellipsis, Flag, Heart, Leaf, Lock, Sparkles, Star } from "lucide-react";
import { getCreator, houseFee, kept, money, type Study } from "@/lib/creators";
import { useHouse } from "@/lib/store";
import { NotFound } from "@/components/not-found";
import { Rule, Sheet } from "@/components/sheet";

export const Route = createFileRoute("/profile/$id")({ component: ProfilePage });

function ProfilePage() {
  const { id } = Route.useParams();
  const creator = getCreator(id);
  const router = useRouter();
  const saved = useHouse((state) => state.saved);
  const joined = useHouse((state) => state.joined);
  const unlocked = useHouse((state) => state.unlocked);
  const toggleSave = useHouse((state) => state.toggleSave);
  const join = useHouse((state) => state.join);
  const leave = useHouse((state) => state.leave);
  const unlock = useHouse((state) => state.unlock);
  const [joinOpen, setJoinOpen] = useState(false);
  const [menu, setMenu] = useState(false);
  const [report, setReport] = useState(false);
  const [reported, setReported] = useState(false);
  const [pay, setPay] = useState<Study | null>(null);
  const [viewing, setViewing] = useState<Study | null>(null);

  if (!creator) return <NotFound />;

  const isSaved = saved.includes(creator.id);
  const isJoined = Boolean(joined[creator.id]);

  function openStudy(study: Study) {
    const free = study.price == null;
    const open = free ? isJoined : unlocked.includes(study.id);
    if (open) setViewing(study);
    else if (free) setJoinOpen(true);
    else setPay(study);
  }

  return (
    <main className="pb-10">
      <div className="relative h-72">
        <img src={creator.portrait} alt="" className="face absolute inset-0 h-full w-full" />
        <div className="absolute inset-0 bg-gradient-to-b from-bg/40 via-transparent to-bg" />
        <button
          type="button"
          aria-label="Back"
          onClick={() => router.history.back()}
          className="glass absolute top-4 left-4 grid size-11 place-items-center rounded-full"
        >
          <ChevronLeft className="size-5" />
        </button>
        <button
          type="button"
          aria-label="More"
          aria-expanded={menu}
          onClick={() => setMenu((value) => !value)}
          className="glass absolute top-4 right-4 grid size-11 place-items-center rounded-full"
        >
          <Ellipsis className="size-5" />
        </button>
        {menu ? (
          <button
            type="button"
            onClick={() => {
              setMenu(false);
              setReport(true);
            }}
            className="glass absolute top-16 right-4 flex items-center gap-2 rounded-full px-4 py-2 text-sm text-ivory"
          >
            <Flag className="size-4 text-gold" />
            Report
          </button>
        ) : null}
      </div>

      <div className="-mt-14 flex flex-col items-center px-5 text-center">
        <div className="relative">
          <div className="rounded-full bg-linear-to-b from-warm to-gold p-0.5">
            <img src={creator.portrait} alt="" className="face size-24 rounded-full object-cover" />
          </div>
          <span className="absolute -right-0.5 -bottom-0.5 grid size-7 place-items-center rounded-full bg-gold text-bg">
            <Star className="size-3.5 fill-current" />
          </span>
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
          <h1 className="font-display text-4xl text-ivory">{creator.name}</h1>
          <span className="inline-flex items-center gap-1 rounded-full bg-gold px-2.5 py-1 text-xs font-medium text-bg">
            <BadgeCheck className="size-3.5" />
            Verified
          </span>
        </div>
        <p className="mt-1 text-sm text-muted">@{creator.handle}</p>
        <p className="mt-3 max-w-xs font-display text-lg text-ivory italic">{creator.bio}</p>

        <div className="mt-4 w-full">
          <Rule />
        </div>

        <div className="rim mt-4 grid w-full grid-cols-3 rounded-card bg-surface/80 py-3">
          <Stat value={String(creator.photos)} label="Photos" />
          <Stat value={String(creator.followers)} label="Followers" divided />
          <Stat value={String(creator.following)} label="Following" divided />
        </div>

        <div className="rim mt-3 grid w-full grid-cols-2 rounded-card bg-surface/80">
          <div className="flex items-center gap-3 px-4 py-3 text-left">
            <Leaf className="size-6 shrink-0 text-gold" strokeWidth={1.25} />
            <div>
              <p className="text-xs tracking-widest text-muted">MEMBER SINCE</p>
              <p className="font-display text-xl text-ivory">{creator.since}</p>
            </div>
          </div>
          <div className="flex items-center gap-3 border-l border-gold/25 px-4 py-3 text-left">
            <Sparkles className="size-6 shrink-0 text-gold" strokeWidth={1.25} />
            <div>
              <p className="text-xs tracking-widest text-muted">PREMIUM TIER</p>
              <p className="font-display text-xl text-gold italic">{creator.tier}</p>
            </div>
          </div>
        </div>

        {isJoined ? (
          <div className="mt-5 w-full">
            <p className="btn-line flex h-14 items-center justify-center rounded-full font-display text-2xl">
              In the circle · {money(joined[creator.id] ?? creator.price)}/mo
            </p>
            <button type="button" className="mt-2 text-sm text-muted" onClick={() => leave(creator.id)}>
              Leave quietly
            </button>
          </div>
        ) : (
          <button type="button" className="btn-gold mt-5 h-14 w-full rounded-full font-display text-2xl" onClick={() => setJoinOpen(true)}>
            Join · {money(creator.price)}/mo
          </button>
        )}

        {creator.live ? (
          <Link to="/live/$id" params={{ id: creator.id }} className="mt-3 text-sm tracking-widest text-gold">
            LIVE NOW
          </Link>
        ) : null}

        <div className="mt-4 flex w-full items-center justify-between px-2 text-sm text-muted">
          <button type="button" className="flex items-center gap-2" onClick={() => toggleSave(creator.id)}>
            <Heart className={isSaved ? "size-4 fill-gold text-gold" : "size-4 text-gold"} />
            {isSaved ? "In your favorites" : "Add to favorites"}
          </button>
          <button type="button" aria-label="Report" onClick={() => setReport(true)}>
            <Flag className="size-4 text-muted" />
          </button>
        </div>
      </div>

      <section className="mt-8 px-5">
        <h2 className="text-xs tracking-widest text-gold">STUDIES</h2>
        <ul className="mt-3 grid grid-cols-2 gap-3">
          {creator.studies.map((study) => {
            const free = study.price == null;
            const open = free ? isJoined : unlocked.includes(study.id);
            return (
              <li key={study.id}>
                <button type="button" onClick={() => openStudy(study)} className="rim w-full overflow-hidden rounded-card text-left">
                  <div className="relative h-36">
                    <img
                      src={creator.portrait}
                      alt=""
                      className={`${study.focus} h-full w-full ${open ? "" : "scale-105 blur-md"}`}
                    />
                    {open ? null : (
                      <span className="absolute inset-0 grid place-items-center text-gold">
                        <Lock className="size-5" />
                      </span>
                    )}
                  </div>
                  <span className="block px-3 py-2">
                    <span className="block font-display text-lg text-ivory">{study.title}</span>
                    <span className="text-xs text-muted">
                      {open ? "Open" : free ? "With the circle" : money(study.price ?? 0)}
                    </span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
        <p className="mt-4 text-center text-xs text-muted">
          {creator.city} · {creator.role} · {creator.age}
        </p>
      </section>

      {joinOpen ? (
        <Sheet title="Join the circle" onClose={() => setJoinOpen(false)}>
          <p className="font-display text-3xl text-ivory">{money(creator.price)} / month</p>
          <p className="mt-2 text-sm text-muted">A membership, not a feed. Renews only while you stay.</p>
          <p className="mt-4 text-sm text-ivory">
            {creator.name} keeps {money(kept(creator.price))}. The house keeps {money(houseFee(creator.price))}.
          </p>
          <button
            type="button"
            className="btn-gold mt-6 h-12 w-full rounded-full font-display text-2xl"
            onClick={() => {
              join(creator.id, creator.price);
              setJoinOpen(false);
            }}
          >
            Join · {money(creator.price)}/mo
          </button>
        </Sheet>
      ) : null}

      {pay ? (
        <Sheet title={pay.title} onClose={() => setPay(null)}>
          <p className="text-sm text-muted">A study, sold once. They keep 85%.</p>
          <p className="mt-3 font-display text-3xl text-ivory">{money(pay.price ?? 0)}</p>
          <p className="mt-2 text-sm text-ivory">
            {creator.name} keeps {money(kept(pay.price ?? 0))}.
          </p>
          <button
            type="button"
            className="btn-gold mt-6 h-12 w-full rounded-full font-display text-2xl"
            onClick={() => {
              unlock(pay.id, creator.id, pay.title, pay.price ?? 0);
              setViewing(pay);
              setPay(null);
            }}
          >
            Unlock
          </button>
        </Sheet>
      ) : null}

      {viewing ? (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-bg/80 p-4" role="dialog" aria-label={viewing.title}>
          <div className="w-full max-w-md">
            <img src={creator.portrait} alt="" className={`${viewing.focus} max-h-[70dvh] w-full rounded-card`} />
            <p className="mt-3 font-display text-3xl text-ivory">{viewing.title}</p>
            <p className="text-sm text-muted">{creator.name}</p>
            <button type="button" className="btn-line mt-4 h-11 w-full rounded-full" onClick={() => setViewing(null)}>
              Close
            </button>
          </div>
        </div>
      ) : null}

      {report ? (
        <Sheet title="For the house" onClose={() => setReport(false)}>
          {reported ? (
            <p className="text-sm text-ivory">Noted. The house will review it against the standard.</p>
          ) : (
            <ul className="space-y-2">
              {["Below the standard", "Harsh or careless light", "Not the person pictured", "Something else"].map((reason) => (
                <li key={reason}>
                  <button
                    type="button"
                    className="btn-line h-11 w-full rounded-full text-sm"
                    onClick={() => setReported(true)}
                  >
                    {reason}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Sheet>
      ) : null}
    </main>
  );
}

function Stat({ value, label, divided }: { value: string; label: string; divided?: boolean }) {
  return (
    <div className={divided ? "border-l border-gold/25" : ""}>
      <p className="font-display text-3xl text-ivory tabular-nums">{value}</p>
      <p className="text-xs text-muted">{label}</p>
    </div>
  );
}
