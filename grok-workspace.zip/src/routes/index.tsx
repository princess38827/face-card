import { createFileRoute, Link } from "@tanstack/react-router";
import { Heart } from "lucide-react";
import { creators } from "@/lib/creators";
import { useHouse } from "@/lib/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const saved = useHouse((state) => state.saved);
  const toggleSave = useHouse((state) => state.toggleSave);
  const live = creators.find((creator) => creator.live);

  return (
    <main>
      <header className="flex items-end justify-between px-5 pt-6 pb-4">
        <h1 className="wordmark text-4xl text-gold">Face-card</h1>
        {live ? (
          <Link
            to="/live/$id"
            params={{ id: live.id }}
            className="mb-1.5 flex items-center gap-2 text-xs tracking-widest text-gold"
          >
            <span className="live-pip" />
            LIVE
          </Link>
        ) : null}
      </header>
      <div className="flex flex-col gap-3 px-4 pb-6">
        {creators.map((creator) => {
          const kept = saved.includes(creator.id);
          return (
            <article key={creator.id} className="rim relative h-44 overflow-hidden rounded-card">
              <img src={creator.portrait} alt="" className="face-card absolute inset-0 h-full w-full" />
              <div className="absolute inset-0 bg-linear-to-r from-bg via-bg/50 to-transparent" />
              <Link
                to="/profile/$id"
                params={{ id: creator.id }}
                aria-label={creator.name}
                className="absolute inset-0 z-10"
              />
              <div className="pointer-events-none absolute inset-x-0 bottom-0 z-20 p-4 pr-16">
                <h2 className="font-display text-2xl text-gold">{creator.name}</h2>
                <p className="text-sm text-ivory/80">
                  {creator.city} · {creator.role} · {creator.age}
                </p>
              </div>
              <button
                type="button"
                className="absolute right-2 bottom-2 z-30 grid size-11 place-items-center"
                aria-label={kept ? `Remove ${creator.name} from favorites` : `Save ${creator.name}`}
                aria-pressed={kept}
                onClick={() => toggleSave(creator.id)}
              >
                <Heart
                  className={kept ? "size-5 fill-gold text-gold" : "size-5 text-gold"}
                  strokeWidth={1.5}
                />
              </button>
            </article>
          );
        })}
      </div>
    </main>
  );
}
