import { useEffect, useState, type ReactNode } from "react";
import { createFileRoute, useNavigate, useRouter } from "@tanstack/react-router";
import { ChevronLeft } from "lucide-react";
import { money } from "@/lib/creators";
import { useHouse } from "@/lib/store";

export const Route = createFileRoute("/apply")({ component: Apply });

const ALLOWED = [
  "Soft glamour, editorial, and sensual imagery",
  "Artistic, tasteful nudity with soft lighting",
  "Solo presence, implied intimacy, lingerie, sheer fabrics",
  "High-production live streams with intentional framing",
  "Lifestyle, fashion, beauty, and personality",
  "Short films and pictorial series",
];

const REFUSED = [
  "Explicit sexual acts, penetration, or hardcore pornography",
  "Extreme fetish, bodily fluids, or degrading content",
  "Low-effort, harsh lighting, or messy webcam energy",
  "Anyone 17 or under — zero tolerance",
  "Hate speech, violence, or illegal activity",
];

function Apply() {
  const router = useRouter();
  const navigate = useNavigate();
  const hydrated = useHouse((state) => state.hydrated);
  const application = useHouse((state) => state.application);
  const patch = useHouse((state) => state.patchApplication);
  const approve = useHouse((state) => state.approve);
  const [preview, setPreview] = useState<string | null>(null);
  const [reviewing, setReviewing] = useState(false);

  useEffect(() => {
    if (hydrated && !application) patch({});
  }, [hydrated, application, patch]);

  useEffect(() => {
    return () => {
      if (preview) URL.revokeObjectURL(preview);
    };
  }, [preview]);

  if (!hydrated || !application) {
    return (
      <main className="grid min-h-full place-items-center">
        <p className="font-display text-2xl text-gold">Opening your card…</p>
      </main>
    );
  }

  if (application.approved) {
    return (
      <main className="flex min-h-full flex-col justify-center px-6 py-10">
        <p className="text-xs tracking-widest text-gold">APPROVED</p>
        <h1 className="mt-3 font-display text-4xl text-ivory">Your face-card is now active.</h1>
        <p className="mt-4 font-display text-xl text-warm italic">
          “Your application has been approved. Your face-card is now active. Welcome.”
        </p>
        <ul className="mt-6 space-y-2 text-sm text-muted">
          <li>Treat the profile like a private members’ club.</li>
          <li>Quality over quantity. Soft light and a strong face win.</li>
          <li>You keep 85% of every earning. The house keeps 15%.</li>
        </ul>
        <button
          type="button"
          className="btn-gold mt-8 h-12 rounded-full font-display text-2xl"
          onClick={() => void navigate({ to: "/me" })}
        >
          Enter the house
        </button>
      </main>
    );
  }

  const stepDone = [
    application.portraitReady && application.name.trim().length >= 2,
    application.bio.trim().length >= 40,
    application.priceSet,
    application.guidelines,
    application.ofAge && application.verified,
    Boolean(application.scheduled),
  ];
  const requiredReady = stepDone.slice(0, 5).every(Boolean);

  return (
    <main className="px-5 pt-4 pb-12">
      <button type="button" aria-label="Back" onClick={() => router.history.back()} className="grid size-11 place-items-center text-ivory">
        <ChevronLeft className="size-5" />
      </button>
      <p className="mt-2 text-xs tracking-widest text-gold">CREATOR ONBOARDING</p>
      <h1 className="mt-2 font-display text-4xl text-ivory">Welcome to Face-card.</h1>
      <div className="rim mt-4 rounded-card bg-surface/80 p-4 text-sm text-ivory">
        <p>You were selected because your presence already meets the standard.</p>
        <p className="mt-2">Here, the face-card never declines. We protect that standard together.</p>
        <p className="mt-2 text-muted">
          Your profile begins in review. Once approved you may post, go live, subscribe, and message.
        </p>
      </div>

      <ol className="mt-6 space-y-3">
        <Step n={1} title="Primary portrait" done={stepDone[0]} open>
          <label className="block text-xs tracking-widest text-muted">NAME ON THE CARD</label>
          <input
            value={application.name}
            onChange={(event) => patch({ name: event.target.value })}
            placeholder="Your name"
            className="rim mt-2 h-12 w-full rounded-card bg-transparent px-4 outline-none"
          />
          <label className="rim mt-3 flex h-28 cursor-pointer flex-col items-center justify-center rounded-card text-sm text-muted">
            {preview ? (
              <img src={preview} alt="" className="h-full w-full rounded-card object-cover" />
            ) : (
              <span>Upload a portrait · soft light, strong face</span>
            )}
            <input
              type="file"
              accept="image/*"
              className="sr-only"
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (!file) return;
                if (preview) URL.revokeObjectURL(preview);
                setPreview(URL.createObjectURL(file));
                patch({ portraitReady: true });
              }}
            />
          </label>
          <button type="button" className="mt-2 text-sm text-gold" onClick={() => patch({ portraitReady: true })}>
            The house will wait for the file
          </button>
        </Step>

        <Step n={2} title="A short bio" done={stepDone[1]} open={stepDone[0]}>
          <textarea
            value={application.bio}
            onChange={(event) => patch({ bio: event.target.value })}
            placeholder="Two or three elegant sentences."
            className="rim min-h-28 w-full rounded-card bg-transparent px-4 py-3 text-sm outline-none"
          />
          <p className="mt-1 text-xs text-muted">{application.bio.trim().length < 40 ? "A little longer." : "That will do."}</p>
        </Step>

        <Step n={3} title="Subscription" done={stepDone[2]} open={stepDone[1]}>
          <p className="font-display text-4xl text-ivory">{money(application.price)}<span className="text-lg text-muted">/mo</span></p>
          <input
            type="range"
            min={9}
            max={29}
            value={application.price}
            aria-label="Subscription price"
            onChange={(event) => patch({ price: Number(event.target.value) })}
            className="mt-3 w-full accent-gold"
          />
          <p className="text-xs text-muted">Recommended $9–$19. You keep 85%.</p>
          <button type="button" className="btn-line mt-3 h-10 rounded-full px-4 text-sm" onClick={() => patch({ priceSet: true })}>
            Use {money(application.price)}
          </button>
        </Step>

        <Step n={4} title="Content guidelines" done={stepDone[3]} open={stepDone[2]}>
          <p className="text-sm text-muted">Every post should be able to live in a modern magazine.</p>
          <p className="mt-3 text-xs tracking-widest text-gold">ALLOWED</p>
          <ul className="mt-1 list-disc space-y-1 pl-4 text-sm text-ivory">
            {ALLOWED.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
          <p className="mt-3 text-xs tracking-widest text-gold">NOT ALLOWED</p>
          <ul className="mt-1 list-disc space-y-1 pl-4 text-sm text-ivory">
            {REFUSED.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
          <label className="mt-4 flex items-start gap-3 text-sm">
            <input
              type="checkbox"
              className="mt-1 accent-gold"
              checked={application.guidelines}
              onChange={(event) => patch({ guidelines: event.target.checked })}
            />
            I will protect the standard.
          </label>
        </Step>

        <Step n={5} title="Identity" done={stepDone[4]} open={stepDone[3]}>
          <label className="flex items-start gap-3 text-sm">
            <input
              type="checkbox"
              className="mt-1 accent-gold"
              checked={application.ofAge}
              onChange={(event) => patch({ ofAge: event.target.checked, verified: false })}
            />
            I confirm I am 18 or older. Anyone 17 or under is never permitted.
          </label>
          <button
            type="button"
            disabled={!application.ofAge || application.verified}
            className="btn-line mt-3 h-11 w-full rounded-full text-sm disabled:opacity-40"
            onClick={() => {
              window.setTimeout(() => patch({ verified: true }), 700);
            }}
          >
            {application.verified ? "Identity confirmed for review" : "Complete verification"}
          </button>
        </Step>

        <Step n={6} title="First live, if you wish" done={stepDone[5]} open={stepDone[4]}>
          <div className="flex flex-wrap gap-2">
            {["This evening", "Tomorrow", "This weekend", "Not yet"].map((slot) => (
              <button
                key={slot}
                type="button"
                onClick={() => patch({ scheduled: slot })}
                className={`h-10 rounded-full border px-3 text-sm ${application.scheduled === slot ? "border-gold bg-gold text-bg" : "border-gold/30 text-muted"}`}
              >
                {slot}
              </button>
            ))}
          </div>
        </Step>
      </ol>

      <button
        type="button"
        disabled={!requiredReady || reviewing}
        className="btn-gold mt-8 h-14 w-full rounded-full font-display text-2xl disabled:opacity-40"
        onClick={() => {
          setReviewing(true);
          window.setTimeout(() => approve(), 900);
        }}
      >
        {reviewing ? "In review…" : "Submit to the house"}
      </button>
    </main>
  );
}

function Step({
  n,
  title,
  done,
  open,
  children,
}: {
  n: number;
  title: string;
  done?: boolean;
  open?: boolean;
  children: ReactNode;
}) {
  return (
    <li className="rim rounded-card bg-surface/60 p-4">
      <div className="flex items-center gap-3">
        <span className={`grid size-8 place-items-center rounded-full text-sm ${done ? "bg-gold text-bg" : "border border-gold/40 text-gold"}`}>
          {n}
        </span>
        <h2 className="font-display text-2xl text-ivory">{title}</h2>
      </div>
      {open ? <div className="mt-3">{children}</div> : null}
    </li>
  );
}
