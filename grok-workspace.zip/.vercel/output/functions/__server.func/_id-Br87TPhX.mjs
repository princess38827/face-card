import { i as __toESM } from "./_runtime.mjs";
import { C as require_jsx_runtime, S as useRouter, Y as require_react, x as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { _ as Eye, b as ChevronLeft, c as Send, d as Lock, g as Flag, h as Gem, m as Gift, s as Share, v as Ellipsis, x as Bookmark, y as Crown } from "./_libs/lucide-react.mjs";
import { a as Sheet, d as houseFee, f as kept, i as Rule, m as NotFound, o as useHouse, p as money, r as Route$1, s as ROOM_CHAT, u as getCreator } from "./_ssr/router-BDYwPA46.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-Br87TPhX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TIPS = [
	{
		label: "Rose",
		amount: 10
	},
	{
		label: "Champagne",
		amount: 25
	},
	{
		label: "Atelier",
		amount: 50
	},
	{
		label: "Toast",
		amount: 100
	}
];
function LivePage() {
	const { id } = Route$1.useParams();
	const hydrated = useHouse((state) => state.hydrated);
	const application = useHouse((state) => state.application);
	const navigate = useNavigate();
	const creator = getCreator(id);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		if (id === "studio" && !application?.approved) navigate({ to: "/apply" });
	}, [
		hydrated,
		id,
		application?.approved,
		navigate
	]);
	if (id === "studio") {
		if (!hydrated || !application?.approved) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "grid min-h-full place-items-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl text-gold",
				children: "Opening the room…"
			})
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Room, {
			host: true,
			creator: {
				id: "studio",
				name: application.name || "Your card",
				handle: "you",
				city: "The house",
				role: "Founding",
				age: 0,
				price: application.price,
				portrait: "",
				live: true,
				viewers: 18,
				bio: application.bio,
				presence: "The light is yours.",
				since: "Tonight",
				tier: "Curated",
				photos: 0,
				followers: 0,
				following: 0,
				studies: []
			}
		});
	}
	if (!creator) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotFound, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Room, { creator });
}
function Room({ creator, host = false }) {
	const router = useRouter();
	const navigate = useNavigate();
	const saved = useHouse((state) => state.saved.includes(creator.id));
	const toggleSave = useHouse((state) => state.toggleSave);
	const extra = useHouse((state) => state.messages[creator.id] ?? []);
	const sendMessage = useHouse((state) => state.sendMessage);
	const sendTip = useHouse((state) => state.sendTip);
	const requestPrivate = useHouse((state) => state.requestPrivate);
	const requested = useHouse((state) => state.privateRequests.includes(creator.id));
	const unlocked = useHouse((state) => state.unlocked);
	const unlock = useHouse((state) => state.unlock);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [watching, setWatching] = (0, import_react.useState)(creator.viewers);
	const [tipOpen, setTipOpen] = (0, import_react.useState)(false);
	const [chosen, setChosen] = (0, import_react.useState)(null);
	const [privateOpen, setPrivateOpen] = (0, import_react.useState)(false);
	const [exclusiveOpen, setExclusiveOpen] = (0, import_react.useState)(false);
	const [report, setReport] = (0, import_react.useState)(false);
	const [menu, setMenu] = (0, import_react.useState)(false);
	const [ribbon, setRibbon] = (0, import_react.useState)("");
	const endRef = (0, import_react.useRef)(null);
	const greeted = (0, import_react.useRef)(false);
	const lines = [...ROOM_CHAT[creator.id] ?? [], ...extra];
	const locked = creator.studies.filter((study) => study.price != null && !unlocked.includes(study.id));
	(0, import_react.useEffect)(() => {
		const timer = window.setInterval(() => setWatching((value) => value + 1), 9e3);
		return () => window.clearInterval(timer);
	}, []);
	(0, import_react.useEffect)(() => {
		endRef.current?.scrollIntoView({ block: "end" });
	}, [lines.length]);
	(0, import_react.useEffect)(() => {
		if (!host || greeted.current) return;
		if ((useHouse.getState().messages.studio ?? []).some((line) => line.name === "Clara")) {
			greeted.current = true;
			return;
		}
		greeted.current = true;
		const timer = window.setTimeout(() => {
			sendMessage("studio", {
				name: "Clara",
				text: "The light on you is enough.",
				time: clock()
			});
			setRibbon("Clara is in the room");
		}, 2400);
		return () => window.clearTimeout(timer);
	}, [host, sendMessage]);
	function publish(line) {
		sendMessage(creator.id, line);
	}
	function onSend(event) {
		event.preventDefault();
		const text = draft.trim();
		if (!text) return;
		publish({
			name: host ? creator.name : "You",
			text,
			time: clock()
		});
		setDraft("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative min-h-full",
		children: [
			creator.portrait ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: creator.portrait,
				alt: "",
				className: "live-drift face absolute inset-0 h-full w-full"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "stage-glow absolute inset-0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-b from-bg/70 via-bg/15 to-bg/85" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 flex min-h-full flex-col px-4 pt-4 pb-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Back",
								onClick: () => router.history.back(),
								className: "grid size-11 place-items-center text-ivory",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
							}),
							creator.portrait ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: creator.portrait,
								alt: "",
								className: "face size-10 rounded-full object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/media/mark.png",
								alt: "",
								className: "size-10 rounded-xl object-cover"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm font-medium",
									children: "Face-card Live Room"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs tracking-wide text-muted",
									children: "Exclusive · Intimate · Real"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Share",
								className: "grid size-11 place-items-center text-gold",
								onClick: () => setRibbon("Kept for the house"),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": saved ? "Remove bookmark" : "Bookmark",
								"aria-pressed": saved,
								className: "grid size-11 place-items-center text-gold",
								onClick: () => {
									if (creator.id !== "studio") toggleSave(creator.id);
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: saved ? "size-4 fill-gold" : "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "More",
								className: "grid size-11 place-items-center text-gold",
								onClick: () => setMenu((value) => !value),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-4" })
							})
						]
					}),
					menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setMenu(false);
							setReport(true);
						},
						className: "glass mt-2 ml-auto flex items-center gap-2 rounded-full px-4 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, { className: "size-4 text-gold" }), "Report"]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-start justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-2 rounded-full border border-gold/50 px-3 py-1 text-xs tracking-widest text-gold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "live-pip-gold" }), "LIVE"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center justify-end gap-1 text-sm tabular-nums",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5 text-ivory" }), watching.toLocaleString()]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "watching"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-1" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-5xl text-ivory",
						children: creator.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-lg text-gold italic",
						children: creator.presence
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "glass mt-4 rounded-card px-4 py-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rule, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-3 max-h-40 space-y-3 overflow-y-auto",
								children: [lines.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid size-8 shrink-0 place-items-center rounded-full border border-gold/40 font-display text-gold",
										children: line.name.slice(0, 1)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-ivory",
													children: line.name
												}),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted",
													children: line.time
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-ivory/90",
											children: line.text
										})]
									})]
								}, `${line.name}-${line.time}-${index}`)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: endRef })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: onSend,
								className: "mt-3 flex items-center rounded-xl border border-gold/30 px-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: draft,
									onChange: (event) => setDraft(event.target.value),
									placeholder: "Send a private message...",
									"aria-label": "Send a private message",
									className: "h-11 min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-muted"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									"aria-label": "Send",
									className: "grid size-10 place-items-center text-gold",
									disabled: !draft.trim(),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
								})]
							}),
							host ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn-line mt-3 h-12 w-full rounded-2xl text-sm tracking-widest",
								onClick: () => void navigate({ to: "/" }),
								children: "END THE ROOM"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid grid-cols-3 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "btn-line flex flex-col items-center rounded-2xl px-1 py-2.5",
										onClick: () => setTipOpen(true),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "size-4 text-gold" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-1 text-xs tracking-wide text-gold",
												children: "SEND TIP"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs text-muted",
												children: "Gratuity"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "btn-line flex flex-col items-center rounded-2xl px-1 py-2.5",
										onClick: () => setPrivateOpen(true),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gem, { className: "size-4 text-gold" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-1 text-xs tracking-wide text-gold",
												children: "PRIVATE"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs text-muted",
												children: "1:1"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "btn-line flex flex-col items-center rounded-2xl px-1 py-2.5",
										onClick: () => setExclusiveOpen(true),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "size-4 text-gold" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-1 text-xs tracking-wide text-gold",
												children: "EXCLUSIVE"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs text-muted",
												children: "Unlock"
											})
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 flex items-center justify-center gap-2 text-xs text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3" }), "Private · Secure · Discreet"]
							}),
							ribbon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-center text-xs text-gold",
								children: ribbon
							}) : null
						]
					})
				]
			}),
			tipOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				title: "Send a tip",
				onClose: () => {
					setTipOpen(false);
					setChosen(null);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: TIPS.map((tip) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setChosen(tip),
							className: `h-16 rounded-card border ${chosen?.label === tip.label ? "border-gold bg-gold text-bg" : "btn-line"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-display text-xl",
								children: tip.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs",
								children: money(tip.amount)
							})]
						}, tip.label))
					}),
					chosen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-sm text-muted",
						children: [
							creator.name,
							" keeps ",
							money(kept(chosen.amount)),
							". The house keeps ",
							money(houseFee(chosen.amount)),
							"."
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: !chosen,
						className: "btn-gold mt-4 h-12 w-full rounded-full font-display text-2xl disabled:opacity-40",
						onClick: () => {
							if (!chosen) return;
							sendTip(creator.id, chosen.label, chosen.amount);
							publish({
								name: "You",
								text: `Raised a glass — ${chosen.label}.`,
								time: clock()
							});
							setRibbon(`${chosen.label} received`);
							setChosen(null);
							setTipOpen(false);
						},
						children: "Send"
					})
				]
			}) : null,
			privateOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				title: "Private room",
				onClose: () => setPrivateOpen(false),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-ivory",
					children: [
						"A 1:1 with ",
						creator.name,
						", arranged rather than demanded. From $80. They keep 85%."
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: requested,
					className: "btn-gold mt-5 h-12 w-full rounded-full font-display text-2xl disabled:opacity-60",
					onClick: () => {
						requestPrivate(creator.id);
						setRibbon("Your request is with them");
						setPrivateOpen(false);
					},
					children: requested ? "Requested" : "Request the room"
				})]
			}) : null,
			exclusiveOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				title: "Exclusive",
				onClose: () => setExclusiveOpen(false),
				children: locked.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Nothing is held back. The open studies are on their card."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: locked.map((study) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rim flex items-center justify-between rounded-card px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-xl",
							children: study.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "text-sm text-gold",
							onClick: () => {
								unlock(study.id, creator.id, study.title, study.price ?? 0);
								setRibbon(`${study.title} is yours`);
								setExclusiveOpen(false);
							},
							children: money(study.price ?? 0)
						})]
					}, study.id))
				})
			}) : null,
			report ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				title: "For the house",
				onClose: () => setReport(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-ivory",
					children: "Noted. The house will review this room against the standard."
				})
			}) : null
		]
	});
}
function clock() {
	return new Intl.DateTimeFormat("en-US", {
		hour: "numeric",
		minute: "2-digit"
	}).format(/* @__PURE__ */ new Date());
}
//#endregion
export { LivePage as component };
