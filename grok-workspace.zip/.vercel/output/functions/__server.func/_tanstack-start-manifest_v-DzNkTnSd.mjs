//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DzNkTnSd.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/activity",
			"/apply",
			"/discover",
			"/me",
			"/live/$id",
			"/profile/$id"
		],
		preloads: [
			"/assets/index-r5HUkCV7.js",
			"/assets/store-BpGyPTNP.js",
			"/assets/preload-helper-Bvql7h6p.js",
			"/assets/link-CiUkGI2O.js",
			"/assets/useNavigate-DEjW8z3b.js",
			"/assets/createLucideIcon-CDNxZ_Ic.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-r5HUkCV7.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CBpUBWOp.js"]
	},
	"/activity": {
		filePath: "/workspace/src/routes/activity.tsx",
		children: void 0,
		preloads: ["/assets/activity-C4B-_njh.js"]
	},
	"/apply": {
		filePath: "/workspace/src/routes/apply.tsx",
		children: void 0,
		preloads: ["/assets/apply-CzN7uU51.js", "/assets/chevron-left-BqBP6cBm.js"]
	},
	"/discover": {
		filePath: "/workspace/src/routes/discover.tsx",
		children: void 0,
		preloads: ["/assets/discover-CxKXVl6g.js"]
	},
	"/me": {
		filePath: "/workspace/src/routes/me.tsx",
		children: void 0,
		preloads: ["/assets/me-BPZU6zza.js"]
	},
	"/live/$id": {
		filePath: "/workspace/src/routes/live/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-DrqNCdJj.js",
			"/assets/chevron-left-BqBP6cBm.js",
			"/assets/lock-BfBvogcb.js"
		]
	},
	"/profile/$id": {
		filePath: "/workspace/src/routes/profile/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-ZDtuSJfI.js",
			"/assets/chevron-left-BqBP6cBm.js",
			"/assets/lock-BfBvogcb.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
