import { i as __toESM } from "./_runtime.mjs";
import { C as require_jsx_runtime, S as useRouter, Y as require_react, b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { S as BadgeCheck, b as ChevronLeft, d as Lock, f as Leaf, g as Flag, i as Star, o as Sparkles, p as Heart, v as Ellipsis } from "./_libs/lucide-react.mjs";
import { a as Sheet, d as houseFee, f as kept, i as Rule, m as NotFound, n as Route, o as useHouse, p as money, u as getCreator } from "./_ssr/router-BDYwPA46.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-DK3QlHTM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProfilePage() {
	const { id } = Route.useParams();
	const creator = getCreator(id);
	const router = useRouter();
	const saved = useHouse((state) => state.saved);
	const joined = useHouse((state) => state.joined);
	const unlocked = useHouse((state) => state.unlocked);
	const toggleSave = useHouse((state) => state.toggleSave);
	const join = useHouse((state) => state.join);
	const leave = useHouse((state) => state.leave);
	const unlock = useHouse((state) => state.unlock);
	const [joinOpen, setJoinOpen] = (0, import_react.useState)(false);
	const [menu, setMenu] = (0, import_react.useState)(false);
	const [report, setReport] = (0, import_react.useState)(false);
	const [reported, setReported] = (0, import_react.useState)(false);
	const [pay, setPay] = (0, import_react.useState)(null);
	const [viewing, setViewing] = (0, import_react.useState)(null);
	if (!creator) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotFound, {});
	const isSaved = saved.includes(creator.id);
	const isJoined = Boolean(joined[creator.id]);
	function openStudy(study) {
		const free = study.price == null;
		if (free ? isJoined : unlocked.includes(study.id)) setViewing(study);
		else if (free) setJoinOpen(true);
		else setPay(study);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "pb-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative h-72",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: creator.portrait,
						alt: "",
						className: "face absolute inset-0 h-full w-full"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-bg/40 via-transparent to-bg" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Back",
						onClick: () => router.history.back(),
						className: "glass absolute top-4 left-4 grid size-11 place-items-center rounded-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "More",
						"aria-expanded": menu,
						onClick: () => setMenu((value) => !value),
						className: "glass absolute top-4 right-4 grid size-11 place-items-center rounded-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-5" })
					}),
					menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setMenu(false);
							setReport(true);
						},
						className: "glass absolute top-16 right-4 flex items-center gap-2 rounded-full px-4 py-2 text-sm text-ivory",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, { className: "size-4 text-gold" }), "Report"]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "-mt-14 flex flex-col items-center px-5 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-full bg-linear-to-b from-warm to-gold p-0.5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: creator.portrait,
								alt: "",
								className: "face size-24 rounded-full object-cover"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute -right-0.5 -bottom-0.5 grid size-7 place-items-center rounded-full bg-gold text-bg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-3.5 fill-current" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap items-center justify-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-4xl text-ivory",
							children: creator.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1 rounded-full bg-gold px-2.5 py-1 text-xs font-medium text-bg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-3.5" }), "Verified"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: ["@", creator.handle]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-xs font-display text-lg text-ivory italic",
						children: creator.bio
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 w-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rule, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rim mt-4 grid w-full grid-cols-3 rounded-card bg-surface/80 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								value: String(creator.photos),
								label: "Photos"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								value: String(creator.followers),
								label: "Followers",
								divided: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								value: String(creator.following),
								label: "Following",
								divided: true
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rim mt-3 grid w-full grid-cols-2 rounded-card bg-surface/80",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 px-4 py-3 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, {
								className: "size-6 shrink-0 text-gold",
								strokeWidth: 1.25
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-widest text-muted",
								children: "MEMBER SINCE"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xl text-ivory",
								children: creator.since
							})] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 border-l border-gold/25 px-4 py-3 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {
								className: "size-6 shrink-0 text-gold",
								strokeWidth: 1.25
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs tracking-widest text-muted",
								children: "PREMIUM TIER"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xl text-gold italic",
								children: creator.tier
							})] })]
						})]
					}),
					isJoined ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 w-full",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "btn-line flex h-14 items-center justify-center rounded-full font-display text-2xl",
							children: [
								"In the circle · ",
								money(joined[creator.id] ?? creator.price),
								"/mo"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-2 text-sm text-muted",
							onClick: () => leave(creator.id),
							children: "Leave quietly"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn-gold mt-5 h-14 w-full rounded-full font-display text-2xl",
						onClick: () => setJoinOpen(true),
						children: [
							"Join · ",
							money(creator.price),
							"/mo"
						]
					}),
					creator.live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/live/$id",
						params: { id: creator.id },
						className: "mt-3 text-sm tracking-widest text-gold",
						children: "LIVE NOW"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex w-full items-center justify-between px-2 text-sm text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex items-center gap-2",
							onClick: () => toggleSave(creator.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: isSaved ? "size-4 fill-gold text-gold" : "size-4 text-gold" }), isSaved ? "In your favorites" : "Add to favorites"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Report",
							onClick: () => setReport(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, { className: "size-4 text-muted" })
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 px-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xs tracking-widest text-gold",
						children: "STUDIES"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 grid grid-cols-2 gap-3",
						children: creator.studies.map((study) => {
							const free = study.price == null;
							const open = free ? isJoined : unlocked.includes(study.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => openStudy(study),
								className: "rim w-full overflow-hidden rounded-card text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative h-36",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: creator.portrait,
										alt: "",
										className: `${study.focus} h-full w-full ${open ? "" : "scale-105 blur-md"}`
									}), open ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute inset-0 grid place-items-center text-gold",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-5" })
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block px-3 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block font-display text-lg text-ivory",
										children: study.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted",
										children: open ? "Open" : free ? "With the circle" : money(study.price ?? 0)
									})]
								})]
							}) }, study.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-center text-xs text-muted",
						children: [
							creator.city,
							" · ",
							creator.role,
							" · ",
							creator.age
						]
					})
				]
			}),
			joinOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				title: "Join the circle",
				onClose: () => setJoinOpen(false),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-3xl text-ivory",
						children: [money(creator.price), " / month"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "A membership, not a feed. Renews only while you stay."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-sm text-ivory",
						children: [
							creator.name,
							" keeps ",
							money(kept(creator.price)),
							". The house keeps ",
							money(houseFee(creator.price)),
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn-gold mt-6 h-12 w-full rounded-full font-display text-2xl",
						onClick: () => {
							join(creator.id, creator.price);
							setJoinOpen(false);
						},
						children: [
							"Join · ",
							money(creator.price),
							"/mo"
						]
					})
				]
			}) : null,
			pay ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
				title: pay.title,
				onClose: () => setPay(null),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "A study, sold once. They keep 85%."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-display text-3xl text-ivory",
						children: money(pay.price ?? 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-ivory",
						children: [
							creator.name,
							" keeps ",
							money(kept(pay.price ?? 0)),
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn-gold mt-6 h-12 w-full rounded-full font-display text-2xl",
						onClick: () => {
							unlock(pay.id, creator.id, pay.title, pay.price ?? 0);
							setViewing(pay);
							setPay(null);
						},
						children: "Unlock"
					})
				]
			}) : null,
			viewing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center bg-bg/80 p-4",
				role: "dialog",
				"aria-label": viewing.title,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: creator.portrait,
							alt: "",
							className: `${viewing.focus} max-h-[70dvh] w-full rounded-card`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-display text-3xl text-ivory",
							children: viewing.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: creator.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn-line mt-4 h-11 w-full rounded-full",
							onClick: () => setViewing(null),
							children: "Close"
						})
					]
				})
			}) : null,
			report ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				title: "For the house",
				onClose: () => setReport(false),
				children: reported ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-ivory",
					children: "Noted. The house will review it against the standard."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: [
						"Below the standard",
						"Harsh or careless light",
						"Not the person pictured",
						"Something else"
					].map((reason) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn-line h-11 w-full rounded-full text-sm",
						onClick: () => setReported(true),
						children: reason
					}) }, reason))
				})
			}) : null
		]
	});
}
function Stat({ value, label, divided }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: divided ? "border-l border-gold/25" : "",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-3xl text-ivory tabular-nums",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		})]
	});
}
//#endregion
export { ProfilePage as component };
