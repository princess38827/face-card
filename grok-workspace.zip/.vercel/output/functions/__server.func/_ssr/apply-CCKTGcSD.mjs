import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, S as useRouter, Y as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as ChevronLeft } from "../_libs/lucide-react.mjs";
import { o as useHouse, p as money } from "./router-BDYwPA46.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/apply-CCKTGcSD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ALLOWED = [
	"Soft glamour, editorial, and sensual imagery",
	"Artistic, tasteful nudity with soft lighting",
	"Solo presence, implied intimacy, lingerie, sheer fabrics",
	"High-production live streams with intentional framing",
	"Lifestyle, fashion, beauty, and personality",
	"Short films and pictorial series"
];
var REFUSED = [
	"Explicit sexual acts, penetration, or hardcore pornography",
	"Extreme fetish, bodily fluids, or degrading content",
	"Low-effort, harsh lighting, or messy webcam energy",
	"Anyone 17 or under — zero tolerance",
	"Hate speech, violence, or illegal activity"
];
function Apply() {
	const router = useRouter();
	const navigate = useNavigate();
	const hydrated = useHouse((state) => state.hydrated);
	const application = useHouse((state) => state.application);
	const patch = useHouse((state) => state.patchApplication);
	const approve = useHouse((state) => state.approve);
	const [preview, setPreview] = (0, import_react.useState)(null);
	const [reviewing, setReviewing] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (hydrated && !application) patch({});
	}, [
		hydrated,
		application,
		patch
	]);
	(0, import_react.useEffect)(() => {
		return () => {
			if (preview) URL.revokeObjectURL(preview);
		};
	}, [preview]);
	if (!hydrated || !application) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-full place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl text-gold",
			children: "Opening your card…"
		})
	});
	if (application.approved) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-full flex-col justify-center px-6 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-gold",
				children: "APPROVED"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-4xl text-ivory",
				children: "Your face-card is now active."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 font-display text-xl text-warm italic",
				children: "“Your application has been approved. Your face-card is now active. Welcome.”"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-6 space-y-2 text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Treat the profile like a private members’ club." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Quality over quantity. Soft light and a strong face win." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "You keep 85% of every earning. The house keeps 15%." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn-gold mt-8 h-12 rounded-full font-display text-2xl",
				onClick: () => void navigate({ to: "/me" }),
				children: "Enter the house"
			})
		]
	});
	const stepDone = [
		application.portraitReady && application.name.trim().length >= 2,
		application.bio.trim().length >= 40,
		application.priceSet,
		application.guidelines,
		application.ofAge && application.verified,
		Boolean(application.scheduled)
	];
	const requiredReady = stepDone.slice(0, 5).every(Boolean);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "px-5 pt-4 pb-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": "Back",
				onClick: () => router.history.back(),
				className: "grid size-11 place-items-center text-ivory",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs tracking-widest text-gold",
				children: "CREATOR ONBOARDING"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl text-ivory",
				children: "Welcome to Face-card."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rim mt-4 rounded-card bg-surface/80 p-4 text-sm text-ivory",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You were selected because your presence already meets the standard." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2",
						children: "Here, the face-card never declines. We protect that standard together."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: "Your profile begins in review. Once approved you may post, go live, subscribe, and message."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-6 space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
						n: 1,
						title: "Primary portrait",
						done: stepDone[0],
						open: true,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs tracking-widest text-muted",
								children: "NAME ON THE CARD"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: application.name,
								onChange: (event) => patch({ name: event.target.value }),
								placeholder: "Your name",
								className: "rim mt-2 h-12 w-full rounded-card bg-transparent px-4 outline-none"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "rim mt-3 flex h-28 cursor-pointer flex-col items-center justify-center rounded-card text-sm text-muted",
								children: [preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: preview,
									alt: "",
									className: "h-full w-full rounded-card object-cover"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Upload a portrait · soft light, strong face" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/*",
									className: "sr-only",
									onChange: (event) => {
										const file = event.target.files?.[0];
										if (!file) return;
										if (preview) URL.revokeObjectURL(preview);
										setPreview(URL.createObjectURL(file));
										patch({ portraitReady: true });
									}
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "mt-2 text-sm text-gold",
								onClick: () => patch({ portraitReady: true }),
								children: "The house will wait for the file"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
						n: 2,
						title: "A short bio",
						done: stepDone[1],
						open: stepDone[0],
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: application.bio,
							onChange: (event) => patch({ bio: event.target.value }),
							placeholder: "Two or three elegant sentences.",
							className: "rim min-h-28 w-full rounded-card bg-transparent px-4 py-3 text-sm outline-none"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: application.bio.trim().length < 40 ? "A little longer." : "That will do."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
						n: 3,
						title: "Subscription",
						done: stepDone[2],
						open: stepDone[1],
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-display text-4xl text-ivory",
								children: [money(application.price), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-lg text-muted",
									children: "/mo"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 9,
								max: 29,
								value: application.price,
								"aria-label": "Subscription price",
								onChange: (event) => patch({ price: Number(event.target.value) }),
								className: "mt-3 w-full accent-gold"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "Recommended $9–$19. You keep 85%."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "btn-line mt-3 h-10 rounded-full px-4 text-sm",
								onClick: () => patch({ priceSet: true }),
								children: ["Use ", money(application.price)]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
						n: 4,
						title: "Content guidelines",
						done: stepDone[3],
						open: stepDone[2],
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "Every post should be able to live in a modern magazine."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs tracking-widest text-gold",
								children: "ALLOWED"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-1 list-disc space-y-1 pl-4 text-sm text-ivory",
								children: ALLOWED.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs tracking-widest text-gold",
								children: "NOT ALLOWED"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-1 list-disc space-y-1 pl-4 text-sm text-ivory",
								children: REFUSED.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-4 flex items-start gap-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									className: "mt-1 accent-gold",
									checked: application.guidelines,
									onChange: (event) => patch({ guidelines: event.target.checked })
								}), "I will protect the standard."]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Step, {
						n: 5,
						title: "Identity",
						done: stepDone[4],
						open: stepDone[3],
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-start gap-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "mt-1 accent-gold",
								checked: application.ofAge,
								onChange: (event) => patch({
									ofAge: event.target.checked,
									verified: false
								})
							}), "I confirm I am 18 or older. Anyone 17 or under is never permitted."]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: !application.ofAge || application.verified,
							className: "btn-line mt-3 h-11 w-full rounded-full text-sm disabled:opacity-40",
							onClick: () => {
								window.setTimeout(() => patch({ verified: true }), 700);
							},
							children: application.verified ? "Identity confirmed for review" : "Complete verification"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
						n: 6,
						title: "First live, if you wish",
						done: stepDone[5],
						open: stepDone[4],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								"This evening",
								"Tomorrow",
								"This weekend",
								"Not yet"
							].map((slot) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => patch({ scheduled: slot }),
								className: `h-10 rounded-full border px-3 text-sm ${application.scheduled === slot ? "border-gold bg-gold text-bg" : "border-gold/30 text-muted"}`,
								children: slot
							}, slot))
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: !requiredReady || reviewing,
				className: "btn-gold mt-8 h-14 w-full rounded-full font-display text-2xl disabled:opacity-40",
				onClick: () => {
					setReviewing(true);
					window.setTimeout(() => approve(), 900);
				},
				children: reviewing ? "In review…" : "Submit to the house"
			})
		]
	});
}
function Step({ n, title, done, open, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "rim rounded-card bg-surface/60 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `grid size-8 place-items-center rounded-full text-sm ${done ? "bg-gold text-bg" : "border border-gold/40 text-gold"}`,
				children: n
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl text-ivory",
				children: title
			})]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3",
			children
		}) : null]
	});
}
//#endregion
export { Apply as component };
