import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as Search } from "../_libs/lucide-react.mjs";
import { l as creators, o as useHouse } from "./router-BDYwPA46.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/discover-rrmtBsR_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = [
	"All",
	"Live",
	"Saved",
	"Paris",
	"Côte d'Azur",
	"Marrakech",
	"Milan",
	"London",
	"Beirut"
];
function Discover() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("All");
	const saved = useHouse((state) => state.saved);
	const shown = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		return creators.filter((creator) => {
			if (!(!needle || [
				creator.name,
				creator.city,
				creator.role,
				creator.handle
			].some((value) => value.toLowerCase().includes(needle)))) return false;
			if (filter === "Live") return creator.live;
			if (filter === "Saved") return saved.includes(creator.id);
			if (filter !== "All") return creator.city === filter;
			return true;
		});
	}, [
		query,
		filter,
		saved
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "px-4 pt-6 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl text-gold",
				children: "Discover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "The house, by name and by city."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "rim mt-5 flex h-12 items-center gap-3 rounded-full px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (event) => setQuery(event.target.value),
					placeholder: "Search the house",
					className: "w-full bg-transparent text-sm outline-none placeholder:text-muted",
					"aria-label": "Search the house"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex gap-2 overflow-x-auto pb-1",
				children: FILTERS.map((item) => {
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setFilter(item),
						className: `h-9 shrink-0 rounded-full border px-4 text-sm ${item === filter ? "border-gold bg-gold text-bg" : "border-gold/30 text-muted"}`,
						children: item
					}, item);
				})
			}),
			shown.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 text-center font-display text-2xl text-muted",
				children: "No one in the house by that name."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 grid grid-cols-2 gap-3",
				children: shown.map((creator) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/profile/$id",
					params: { id: creator.id },
					className: "rim block overflow-hidden rounded-card",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative aspect-3/4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: creator.portrait,
								alt: "",
								className: "face absolute inset-0 h-full w-full"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-bg via-transparent to-transparent" }),
							creator.live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "absolute top-2 right-2 flex items-center gap-1.5 rounded-full bg-bg/70 px-2 py-1 text-xs tracking-widest text-gold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "live-pip" }), "LIVE"]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute inset-x-0 bottom-0 p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-xl leading-none text-ivory",
									children: creator.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted",
									children: creator.city
								})]
							})
						]
					})
				}) }, creator.id))
			})
		]
	});
}
//#endregion
export { Discover as component };
