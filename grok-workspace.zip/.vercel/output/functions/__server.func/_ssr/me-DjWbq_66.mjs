import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as creators, o as useHouse, p as money } from "./router-BDYwPA46.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/me-DjWbq_66.js
var import_jsx_runtime = require_jsx_runtime();
function Me() {
	const saved = useHouse((state) => state.saved);
	const joined = useHouse((state) => state.joined);
	const tips = useHouse((state) => state.tips);
	const application = useHouse((state) => state.application);
	const kept = creators.filter((creator) => saved.includes(creator.id));
	const circles = creators.filter((creator) => joined[creator.id]);
	const approved = Boolean(application?.approved);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "px-4 pt-6 pb-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl text-gold",
				children: "Your card"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rim mt-5 rounded-card bg-surface/80 p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/media/mark.png",
						alt: "",
						className: "size-16 rounded-2xl object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl text-ivory",
						children: approved ? application?.name || "Your card" : circles.length ? "Member" : "Guest of the house"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: approved ? "Face-card active" : "Founding circle · by invitation of taste"
					})] })]
				}), approved && application ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 font-display text-lg text-warm italic",
					children: application.bio
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted",
					children: "Because the face-card never declines. Keep the faces that stay with you."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xs tracking-widest text-gold",
					children: "FAVORITES"
				}), kept.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "Faces you keep will rest here."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 flex gap-3 overflow-x-auto",
					children: kept.map((creator) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/profile/$id",
						params: { id: creator.id },
						className: "block w-20 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: creator.portrait,
							alt: "",
							className: "face size-20 rounded-full object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block truncate text-xs text-muted",
							children: creator.name
						})]
					}) }, creator.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xs tracking-widest text-gold",
					children: "CIRCLES"
				}), circles.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "You have not joined a circle yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: circles.map((creator) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/profile/$id",
						params: { id: creator.id },
						className: "rim flex items-center justify-between rounded-card px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-xl",
							children: creator.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm text-gold",
							children: [money(joined[creator.id] ?? creator.price), "/mo"]
						})]
					}) }, creator.id))
				})]
			}),
			tips.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xs tracking-widest text-gold",
					children: "GRATUITIES"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: tips.map((tip) => {
						const name = creators.find((creator) => creator.id === tip.creatorId)?.name ?? "the house";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "text-sm text-muted",
							children: [
								tip.label,
								" for ",
								name,
								" · ",
								money(tip.amount)
							]
						}, tip.id);
					})
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rim mt-8 rounded-card p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl text-ivory",
						children: "85 / 15"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Creators keep 85% of every subscription, tip, and study. The house retains 15% — more generous than the rooms it replaces."
					}),
					approved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/live/$id",
						params: { id: "studio" },
						className: "btn-gold mt-5 flex h-12 items-center justify-center rounded-full font-display text-2xl",
						children: "Go live"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/apply",
						className: "btn-gold mt-5 flex h-12 items-center justify-center rounded-full font-display text-2xl",
						children: application ? "Continue your request" : "Request a face-card"
					})
				]
			})
		]
	});
}
//#endregion
export { Me as component };
