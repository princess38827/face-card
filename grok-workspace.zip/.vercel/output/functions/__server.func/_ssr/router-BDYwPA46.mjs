import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, S as useRouter, Y as require_react, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, x as useNavigate, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as SquareStack, l as Search, n as UserRound, p as Heart, r as TriangleAlert, t as X, u as Plus } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-BDYwPA46.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
function NotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-full flex-col items-center justify-center gap-4 px-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-4xl text-gold",
				children: "Not in the house"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "This card was never issued."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "btn-gold mt-2 rounded-full px-6 py-3 font-display text-xl",
				children: "Return home"
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var creators = [
	{
		id: "amelia",
		name: "Amelia V.",
		handle: "ameliav",
		city: "Paris",
		role: "Creative Director",
		age: 28,
		price: 12,
		portrait: "/portraits/amelia.jpg",
		live: true,
		viewers: 1248,
		bio: "Quiet light. Curated rooms. I make pictures for people who still look closely.",
		presence: "Your presence is a privilege.",
		since: "March 2024",
		tier: "Curated",
		photos: 128,
		followers: 24,
		following: 6,
		studies: [{
			id: "amelia-collar",
			title: "Collar and gold",
			price: null,
			focus: "face-card"
		}, {
			id: "amelia-rue",
			title: "Rue des Archives",
			price: 12,
			focus: "face-tight"
		}]
	},
	{
		id: "julian",
		name: "Julian Moreau",
		handle: "julianmoreau",
		city: "Côte d'Azur",
		role: "Architect",
		age: 31,
		price: 15,
		portrait: "/portraits/julian.jpg",
		live: false,
		viewers: 0,
		bio: "I build houses that know how to be quiet. The coast is the studio. Stone does the talking.",
		presence: "Stay for the long light.",
		since: "June 2023",
		tier: "Curated",
		photos: 64,
		followers: 22,
		following: 5,
		studies: [{
			id: "julian-stone",
			title: "Stone and noon",
			price: null,
			focus: "face-card"
		}, {
			id: "julian-terrace",
			title: "The long terrace",
			price: 15,
			focus: "face-tight"
		}]
	},
	{
		id: "sofia",
		name: "Sofia El-Masri",
		handle: "sofiaelmasri",
		city: "Marrakech",
		role: "Photographer",
		age: 27,
		price: 18,
		portrait: "/portraits/sofia.jpg",
		live: false,
		viewers: 0,
		bio: "I photograph faces before I photograph places. Dusk here is its own kind of gold.",
		presence: "Look once, then look properly.",
		since: "January 2025",
		tier: "Curated",
		photos: 86,
		followers: 31,
		following: 9,
		studies: [{
			id: "sofia-dusk",
			title: "Dusk on the medina",
			price: null,
			focus: "face-card"
		}, {
			id: "sofia-face",
			title: "A face before the place",
			price: 12,
			focus: "face-tight"
		}]
	},
	{
		id: "elena",
		name: "Elena Voss",
		handle: "elenavoss",
		city: "Milan",
		role: "Editor",
		age: 33,
		price: 9,
		portrait: "/portraits/elena.jpg",
		live: false,
		viewers: 0,
		bio: "I edit pages that still believe in paper. A good sentence should feel as inevitable as a collar.",
		presence: "Fewer words. Better ones.",
		since: "November 2024",
		tier: "Curated",
		photos: 41,
		followers: 19,
		following: 6,
		studies: [{
			id: "elena-collar",
			title: "The collar",
			price: null,
			focus: "face-tight"
		}, {
			id: "elena-margin",
			title: "Margin notes",
			price: 9,
			focus: "face-card"
		}]
	},
	{
		id: "lucien",
		name: "Lucien Hart",
		handle: "lucienhart",
		city: "London",
		role: "Atelier Director",
		age: 44,
		price: 19,
		portrait: "/portraits/lucien.jpg",
		live: false,
		viewers: 0,
		bio: "Twenty years of cloth, cut close and without noise. Elegance is mostly what you refuse.",
		presence: "Nothing extra. Nothing missing.",
		since: "August 2022",
		tier: "Founding",
		photos: 52,
		followers: 18,
		following: 4,
		studies: [{
			id: "lucien-cloth",
			title: "Charcoal cloth",
			price: null,
			focus: "face-card"
		}, {
			id: "lucien-refuse",
			title: "What was refused",
			price: 20,
			focus: "face-tight"
		}]
	},
	{
		id: "noor",
		name: "Noor Haddad",
		handle: "noorhaddad",
		city: "Beirut",
		role: "Stylist",
		age: 30,
		price: 14,
		portrait: "/portraits/noor.jpg",
		live: true,
		viewers: 486,
		bio: "I dress the hour after the invitation. Evening light, and the jewelry that outlasts it.",
		presence: "Stay. The light is finally right.",
		since: "April 2025",
		tier: "Curated",
		photos: 73,
		followers: 27,
		following: 7,
		studies: [{
			id: "noor-after",
			title: "After the invitation",
			price: null,
			focus: "face-card"
		}, {
			id: "noor-gold",
			title: "Gold that stays",
			price: 14,
			focus: "face-tight"
		}]
	}
];
var ROOM_CHAT = {
	amelia: [
		{
			name: "Alexander",
			text: "Your presence lights up the room.",
			time: "10:24 PM"
		},
		{
			name: "Valentino",
			text: "Absolutely stunning, as always.",
			time: "10:25 PM"
		},
		{
			name: "Dominic",
			text: "The elegance is unmatched.",
			time: "10:25 PM"
		},
		{
			name: "Clara",
			text: "Simply unforgettable.",
			time: "10:26 PM"
		}
	],
	noor: [
		{
			name: "Helena",
			text: "The gold at your throat catches the lamp.",
			time: "9:02 PM"
		},
		{
			name: "Marcus",
			text: "Quiet, and completely certain.",
			time: "9:04 PM"
		},
		{
			name: "Adele",
			text: "This is the standard.",
			time: "9:06 PM"
		}
	]
};
var SEED_NOTES = [
	{
		id: "seed-live",
		title: "Amelia V. is live",
		detail: "Paris · a quiet room, open to the house.",
		when: "This hour"
	},
	{
		id: "seed-noor",
		title: "Noor Haddad is live",
		detail: "Beirut · evening light, intentionally framed.",
		when: "This hour"
	},
	{
		id: "seed-sofia",
		title: "A new study from Sofia El-Masri",
		detail: "Dusk on the medina. Soft light, strong face.",
		when: "Last night"
	},
	{
		id: "seed-julian",
		title: "Julian Moreau published a study",
		detail: "The long terrace. Côte d'Azur, late light.",
		when: "Yesterday"
	}
];
function getCreator(id) {
	return creators.find((creator) => creator.id === id);
}
function money(amount) {
	return Number.isInteger(amount) ? `$${amount}` : `$${amount.toFixed(2)}`;
}
function kept(amount) {
	return Math.round(amount * .85 * 100) / 100;
}
function houseFee(amount) {
	return Math.round(amount * .15 * 100) / 100;
}
var blank = () => ({
	name: "",
	bio: "",
	price: 15,
	priceSet: false,
	guidelines: false,
	ofAge: false,
	verified: false,
	portraitReady: false,
	scheduled: null,
	approved: false
});
function note(title, detail) {
	return {
		id: crypto.randomUUID(),
		title,
		detail,
		when: "Just now"
	};
}
function creatorName(id) {
	return creators.find((creator) => creator.id === id)?.name ?? "the house";
}
var useHouse = create()(persist((set, get) => ({
	hydrated: false,
	saved: [],
	joined: {},
	unlocked: [],
	privateRequests: [],
	notes: [],
	messages: {},
	tips: [],
	application: null,
	toggleSave: (id) => {
		const has = get().saved.includes(id);
		const name = creatorName(id);
		set({
			saved: has ? get().saved.filter((item) => item !== id) : [...get().saved, id],
			notes: has ? get().notes : [note(`Kept ${name}`, "Added to your favorites."), ...get().notes].slice(0, 30)
		});
	},
	join: (id, price) => {
		if (get().joined[id]) return;
		set({
			joined: {
				...get().joined,
				[id]: price
			},
			notes: [note(`You joined ${creatorName(id)}`, `${money(price)} / month · they keep 85%.`), ...get().notes].slice(0, 30)
		});
	},
	leave: (id) => {
		const joined = { ...get().joined };
		delete joined[id];
		set({ joined });
	},
	unlock: (id, creatorId, title, amount) => {
		if (get().unlocked.includes(id)) return;
		set({
			unlocked: [...get().unlocked, id],
			notes: [note(`Unlocked ${title}`, `${creatorName(creatorId)} keeps ${money(Math.round(amount * .85 * 100) / 100)}.`), ...get().notes].slice(0, 30)
		});
	},
	requestPrivate: (id) => {
		if (get().privateRequests.includes(id)) return;
		set({
			privateRequests: [...get().privateRequests, id],
			notes: [note(`Private room requested`, `With ${creatorName(id)}. Arranged 1:1, never rushed.`), ...get().notes].slice(0, 30)
		});
	},
	sendTip: (creatorId, label, amount) => {
		set({
			tips: [{
				id: crypto.randomUUID(),
				creatorId,
				label,
				amount,
				when: "Just now"
			}, ...get().tips].slice(0, 30),
			notes: [note(`${label} for ${creatorName(creatorId)}`, `${money(amount)} · they keep 85%.`), ...get().notes].slice(0, 30)
		});
	},
	sendMessage: (roomId, line) => {
		const prev = get().messages[roomId] ?? [];
		set({ messages: {
			...get().messages,
			[roomId]: [...prev, line].slice(-40)
		} });
	},
	patchApplication: (partial) => {
		set({ application: {
			...get().application ?? blank(),
			...partial
		} });
	},
	approve: () => {
		set({
			application: {
				...get().application ?? blank(),
				approved: true
			},
			notes: [note("Your face-card is active", "The house approved your application."), ...get().notes].slice(0, 30)
		});
	}
}), {
	name: "face-card-house",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	partialize: (state) => ({
		saved: state.saved,
		joined: state.joined,
		unlocked: state.unlocked,
		privateRequests: state.privateRequests,
		notes: state.notes,
		messages: state.messages,
		tips: state.tips,
		application: state.application
	})
}));
function Sheet({ title, onClose, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-bg/70",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": title,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute inset-0",
			"aria-label": "Close",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass rim relative z-10 max-h-[85dvh] w-full max-w-md overflow-y-auto rounded-t-card px-5 pt-5 pb-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl text-gold",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					"aria-label": "Close",
					className: "grid size-11 place-items-center text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), children]
		})]
	});
}
function Rule() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 text-gold",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-gold/30" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				width: "10",
				height: "10",
				viewBox: "0 0 10 10",
				fill: "currentColor",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M5 0.5 9.5 5 5 9.5 0.5 5Z" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-gold/30" })
		]
	});
}
function AppFrame({ children }) {
	const path = useRouterState({ select: (state) => state.location.pathname });
	const navigate = useNavigate();
	const [splash, setSplash] = (0, import_react.useState)(true);
	const [compose, setCompose] = (0, import_react.useState)(false);
	const hydrated = useHouse((state) => state.hydrated);
	const application = useHouse((state) => state.application);
	const bare = path.startsWith("/live") || path.startsWith("/profile") || path.startsWith("/apply");
	const liveNow = creators.filter((creator) => creator.live);
	(0, import_react.useEffect)(() => {
		useHouse.persist.rehydrate().finally(() => {
			useHouse.setState({ hydrated: true });
		});
	}, []);
	(0, import_react.useEffect)(() => {
		const timer = window.setTimeout(() => setSplash(false), 1600);
		return () => window.clearTimeout(timer);
	}, []);
	(0, import_react.useEffect)(() => {
		setCompose(false);
	}, [path]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh justify-center overflow-hidden bg-bg text-ivory",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden h-dvh min-w-0 flex-1 flex-col justify-center px-10 xl:flex",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto max-w-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-gold",
							children: "QUIET LUXURY"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "wordmark mt-3 text-5xl text-ivory",
							children: "Face-card"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-display text-xl text-warm italic",
							children: "Because the face-card never declines."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-sm text-muted",
							children: "A curated house for exceptional presence. Founding members only."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 text-sm text-ivory",
							children: "Creators keep 85%."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "The house keeps 15%."
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex h-dvh w-full max-w-md shrink-0 flex-col border-x border-gold/15",
				children: [
					splash && path === "/" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "absolute inset-0 z-40 flex flex-col items-center justify-center bg-bg px-8",
						onClick: () => setSplash(false),
						"aria-label": "Enter Face-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/media/mark.png",
								alt: "",
								className: "mark-glow w-52"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 text-center font-display text-lg text-warm italic",
								children: "Because the face-card never declines."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-8 h-0.5 w-40 overflow-hidden bg-gold/15",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "splash-bar" })
							})
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pane min-h-0 flex-1 overflow-y-auto",
						children
					}),
					bare ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "nav-pad relative grid shrink-0 grid-cols-5 items-end border-t border-gold/20 bg-bg/95 px-1 pt-3 backdrop-blur-xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavItem, {
								to: "/",
								label: "Home",
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquareStack, {
									className: "size-5",
									strokeWidth: 1.5
								}),
								exact: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavItem, {
								to: "/discover",
								label: "Discover",
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
									className: "size-5",
									strokeWidth: 1.5
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "relative h-12",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": "Create",
									onClick: () => setCompose(true),
									className: "btn-gold absolute left-1/2 top-0 grid size-14 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
										className: "size-6",
										strokeWidth: 1.75
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavItem, {
								to: "/activity",
								label: "Activity",
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
									className: "size-5",
									strokeWidth: 1.5
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavItem, {
								to: "/me",
								label: "Profile",
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, {
									className: "size-5",
									strokeWidth: 1.5
								})
							})
						]
					}),
					compose ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
						title: application?.approved ? "Your card" : "The house",
						onClose: () => setCompose(false),
						children: !hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted",
							children: "One moment."
						}) : application?.approved ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xl italic text-ivory",
								children: "Your face-card is active. The room can be yours."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn-gold h-12 w-full rounded-full font-display text-2xl",
								onClick: () => {
									setCompose(false);
									navigate({
										to: "/live/$id",
										params: { id: "studio" }
									});
								},
								children: "Go live"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-ivory",
								children: "A face-card is extended, not claimed. If your presence already meets the standard, request consideration."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn-gold h-12 w-full rounded-full font-display text-2xl",
								onClick: () => {
									setCompose(false);
									navigate({ to: "/apply" });
								},
								children: "Request a card"
							})]
						})
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden h-dvh min-w-0 flex-1 flex-col justify-end px-10 pb-16 xl:flex",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-widest text-gold",
						children: "LIVE NOW"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-3",
						children: liveNow.map((creator) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/live/$id",
							params: { id: creator.id },
							className: "group block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-2xl text-ivory group-hover:text-gold",
								children: creator.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-0.5 block text-sm text-muted",
								children: [
									creator.city,
									" · ",
									creator.viewers.toLocaleString(),
									" watching"
								]
							})]
						}) }, creator.id))
					})]
				})
			})
		]
	});
}
function NavItem({ to, label, icon, exact }) {
	const path = useRouterState({ select: (state) => state.location.pathname });
	const on = exact ? path === to : path === to || path.startsWith(`${to}/`);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: `flex min-h-11 flex-col items-center justify-end gap-1 pb-1 ${on ? "text-gold" : "text-muted"}`,
		children: [icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs",
			children: label
		})]
	});
}
var styles_default = "/assets/styles-3w9aF64u.css";
var Route$7 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Face-card" },
			{
				name: "description",
				content: "Because the face-card never declines."
			},
			{
				name: "theme-color",
				content: "#0F0F0F"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;1,500;1,600&family=Inter:wght@400;500;600&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$6 = () => import("./routes-CFe3rhBg.mjs");
var Route$6 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./activity-DOm9Gwhq.mjs");
var Route$5 = createFileRoute("/activity")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./apply-CCKTGcSD.mjs");
var Route$4 = createFileRoute("/apply")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./discover-rrmtBsR_.mjs");
var Route$3 = createFileRoute("/discover")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./me-DjWbq_66.mjs");
var Route$2 = createFileRoute("/me")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("../_id-Br87TPhX.mjs");
var Route$1 = createFileRoute("/live/$id")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("../_id-DK3QlHTM.mjs");
var Route = createFileRoute("/profile/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$6.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$7
	}),
	ActivityRoute: Route$5.update({
		id: "/activity",
		path: "/activity",
		getParentRoute: () => Route$7
	}),
	ApplyRoute: Route$4.update({
		id: "/apply",
		path: "/apply",
		getParentRoute: () => Route$7
	}),
	DiscoverRoute: Route$3.update({
		id: "/discover",
		path: "/discover",
		getParentRoute: () => Route$7
	}),
	MeRoute: Route$2.update({
		id: "/me",
		path: "/me",
		getParentRoute: () => Route$7
	}),
	LiveIdRoute: Route$1.update({
		id: "/live/$id",
		path: "/live/$id",
		getParentRoute: () => Route$7
	}),
	ProfileIdRoute: Route.update({
		id: "/profile/$id",
		path: "/profile/$id",
		getParentRoute: () => Route$7
	})
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent,
		defaultNotFoundComponent: NotFound
	});
}
//#endregion
export { Sheet as a, SEED_NOTES as c, houseFee as d, kept as f, Rule as i, creators as l, NotFound as m, Route as n, useHouse as o, money as p, Route$1 as r, ROOM_CHAT as s, router_exports as t, getCreator as u };
