import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as Heart } from "../_libs/lucide-react.mjs";
import { l as creators, o as useHouse } from "./router-BDYwPA46.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CFe3rhBg.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const saved = useHouse((state) => state.saved);
	const toggleSave = useHouse((state) => state.toggleSave);
	const live = creators.find((creator) => creator.live);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex items-end justify-between px-5 pt-6 pb-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "wordmark text-4xl text-gold",
			children: "Face-card"
		}), live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/live/$id",
			params: { id: live.id },
			className: "mb-1.5 flex items-center gap-2 text-xs tracking-widest text-gold",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "live-pip" }), "LIVE"]
		}) : null]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-col gap-3 px-4 pb-6",
		children: creators.map((creator) => {
			const kept = saved.includes(creator.id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rim relative h-44 overflow-hidden rounded-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: creator.portrait,
						alt: "",
						className: "face-card absolute inset-0 h-full w-full"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-r from-bg via-bg/50 to-transparent" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/profile/$id",
						params: { id: creator.id },
						"aria-label": creator.name,
						className: "absolute inset-0 z-10"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pointer-events-none absolute inset-x-0 bottom-0 z-20 p-4 pr-16",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl text-gold",
							children: creator.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-ivory/80",
							children: [
								creator.city,
								" · ",
								creator.role,
								" · ",
								creator.age
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "absolute right-2 bottom-2 z-30 grid size-11 place-items-center",
						"aria-label": kept ? `Remove ${creator.name} from favorites` : `Save ${creator.name}`,
						"aria-pressed": kept,
						onClick: () => toggleSave(creator.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
							className: kept ? "size-5 fill-gold text-gold" : "size-5 text-gold",
							strokeWidth: 1.5
						})
					})
				]
			}, creator.id);
		})
	})] });
}
//#endregion
export { Home as component };
